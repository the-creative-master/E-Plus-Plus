#include "vault.hpp"
#include "lexer.hpp"
#include <cctype>
#include <algorithm>
#include <stdexcept>
#include <cstdint>
#include <chrono>
#include <sstream>
#include <vector>
#include <utility>
#include <cerrno>
#include <cstdlib>

namespace epp {

const std::unordered_map<std::string, TokenType> Lexer::keywords = {
    {"say", TokenType::KW_SAY},
    {"tell", TokenType::KW_TELL},
    {"let", TokenType::KW_LET},
    {"be", TokenType::KW_BE},
    {"set", TokenType::KW_SET},
    {"to", TokenType::KW_TO},
    {"define", TokenType::KW_DEFINE},
    {"note", TokenType::KW_NOTE},
    {"it's", TokenType::KW_ITS},
    {"its", TokenType::KW_ITS},
    {"run", TokenType::KW_RUN},
    {"python", TokenType::KW_PYTHON},
    {"code", TokenType::KW_CODE},
    {"ask", TokenType::KW_ASK},
    {"and", TokenType::KW_AND},
    {"save", TokenType::KW_SAVE},
    {"the", TokenType::KW_THE},
    {"output", TokenType::KW_OUTPUT},
    {"answer", TokenType::KW_ANSWER},
    {"result", TokenType::KW_RESULT},
    {"as", TokenType::KW_AS},
    {"in", TokenType::KW_IN},
    {"add", TokenType::KW_ADD},
    {"library", TokenType::KW_LIBRARY},

    {"check", TokenType::KW_CHECK},
    {"if", TokenType::KW_IF},
    {"is", TokenType::KW_IS},
    {"not", TokenType::KW_NOT},
    {"a", TokenType::KW_A},
    {"number", TokenType::KW_NUMBER},

    {"plus", TokenType::KW_PLUS},
    {"minus", TokenType::KW_MINUS},
    {"times", TokenType::KW_TIMES},
    {"multiplied", TokenType::KW_MULTIPLIED},
    {"divided", TokenType::KW_DIVIDED},
    {"by", TokenType::KW_BY},
    {"modulo", TokenType::KW_MODULO},
    {"mod", TokenType::KW_MOD},

    {"concat", TokenType::KW_CONCAT},
    {"it", TokenType::KW_IT},
    {"with", TokenType::KW_WITH},
    {"separation", TokenType::KW_SEPARATION},
    {"seperation", TokenType::KW_SEPARATION},
    {"method", TokenType::KW_METHOD},
    {"of", TokenType::KW_OF},

    {"then", TokenType::KW_THEN},
    {"else", TokenType::KW_ELSE},
    {"otherwise", TokenType::KW_OTHERWISE},
    {"end", TokenType::KW_END},
    {"repeat", TokenType::KW_REPEAT},
    {"while", TokenType::KW_WHILE},
    {"do", TokenType::KW_DO},
    {"equals", TokenType::KW_EQUALS},
    {"equal", TokenType::KW_EQUAL},
    {"greater", TokenType::KW_GREATER},
    {"less", TokenType::KW_LESS},
    {"than", TokenType::KW_THAN},
    {"true", TokenType::KW_TRUE},
    {"false", TokenType::KW_FALSE},

    {"square", TokenType::KW_SQUARE},
    {"root", TokenType::KW_ROOT},
    {"cube", TokenType::KW_CUBE},
    {"how", TokenType::KW_HOW},
    {"much", TokenType::KW_MUCH},
    {"percent", TokenType::KW_PERCENT},
    {"absolute", TokenType::KW_ABSOLUTE},
    {"value", TokenType::KW_VALUE},
    {"power", TokenType::KW_POWER},
    {"raised", TokenType::KW_RAISED},
    {"round", TokenType::KW_ROUND},
    {"floor", TokenType::KW_FLOOR},
    {"ceiling", TokenType::KW_CEILING},
    {"ceil", TokenType::KW_CEIL},
    {"sine", TokenType::KW_SINE},
    {"sin", TokenType::KW_SIN},
    {"cosine", TokenType::KW_COSINE},
    {"cos", TokenType::KW_COS},
    {"tangent", TokenType::KW_TANGENT},
    {"tan", TokenType::KW_TAN},
    {"minimum", TokenType::KW_MINIMUM},
    {"min", TokenType::KW_MIN},
    {"maximum", TokenType::KW_MAXIMUM},
    {"max", TokenType::KW_MAX},
    {"random", TokenType::KW_RANDOM},
    {"between", TokenType::KW_BETWEEN},
    {"logarithm", TokenType::KW_LOGARITHM},
    {"log", TokenType::KW_LOG},
    {"natural", TokenType::KW_NATURAL},
    {"factorial", TokenType::KW_FACTORIAL},
    {"hypotenuse", TokenType::KW_HYPOTENUSE},
    {"pi", TokenType::KW_PI},
    {"e", TokenType::KW_E},

    {"length", TokenType::KW_LENGTH},
    {"uppercase", TokenType::KW_UPPERCASE},
    {"lowercase", TokenType::KW_LOWERCASE},
    {"reverse", TokenType::KW_REVERSE},
    {"first", TokenType::KW_FIRST},
    {"last", TokenType::KW_LAST},
    {"letter", TokenType::KW_LETTER},
    {"replace", TokenType::KW_REPLACE},
    {"current", TokenType::KW_CURRENT},
    {"time", TokenType::KW_TIME},
    {"date", TokenType::KW_DATE},
    {"year", TokenType::KW_YEAR},
    {"timestamp", TokenType::KW_TIMESTAMP},
    {"trim", TokenType::KW_TRIM},
    {"trimmed", TokenType::KW_TRIMMED},
    {"wait", TokenType::KW_WAIT},
    {"sleep", TokenType::KW_SLEEP},
    {"second", TokenType::KW_SECOND},
    {"seconds", TokenType::KW_SECONDS},
    {"millisecond", TokenType::KW_MILLISECOND},
    {"milliseconds", TokenType::KW_MILLISECONDS},

    {"file", TokenType::KW_FILE},
    {"files", TokenType::KW_FILES},
    {"read", TokenType::KW_READ},
    {"write", TokenType::KW_WRITE},
    {"append", TokenType::KW_APPEND},
    {"exists", TokenType::KW_EXISTS},
    {"system", TokenType::KW_SYSTEM},
    {"command", TokenType::KW_COMMAND},
    {"platform", TokenType::KW_PLATFORM},
    {"os", TokenType::KW_OS},
    {"clear", TokenType::KW_CLEAR},
    {"console", TokenType::KW_CONSOLE},
    {"screen", TokenType::KW_SCREEN},
    {"red", TokenType::KW_RED},
    {"green", TokenType::KW_GREEN},
    {"blue", TokenType::KW_BLUE},
    {"yellow", TokenType::KW_YELLOW},
    {"cyan", TokenType::KW_CYAN},
    {"magenta", TokenType::KW_MAGENTA},
    {"roll", TokenType::KW_ROLL},
    {"dice", TokenType::KW_DICE},
    {"flip", TokenType::KW_FLIP},
    {"coin", TokenType::KW_COIN},
    {"sides", TokenType::KW_SIDES}
};

std::string Lexer::to_lower(const std::string& s) {
    std::string res = s;
    std::transform(res.begin(), res.end(), res.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return res;
}

Lexer::Lexer(const std::string& source) : src(source) {
    // Studio opens its saved projects before passing their plaintext to the
    // WebAssembly lexer. The native CLI continues to open vaults here.
#ifndef EPP_BROWSER_PLAINTEXT
    if (is_vault(src)) {
        src = open_vault(src);
    }
#endif
}

// F001-F015: the fifteen ways the lexer itself can give up. The names and
// fixes are the same strings js/errors.js prints, so a fatal error reads the
// same in the browser, on the command line and in E++.zip.
const char* Lexer::catalogue_name(const std::string& code) {
    if (code == "E064") return "Unexpected End Of Program";
    if (code == "F001") return "Lexer Received Invalid Input";
    if (code == "F002") return "The Program Is Too Large To Lex";
    if (code == "F003") return "Unrecognised Character";
    if (code == "F004") return "Unterminated String";
    if (code == "F005") return "Unterminated Variable Name";
    if (code == "F006") return "Empty Variable Reference";
    if (code == "F007") return "Reserved Lexer Code";
    if (code == "F008") return "Note Without Brackets";
    if (code == "F009") return "Line Contains A Null Character";
    if (code == "F010") return "Unrecognised Number";
    if (code == "F011") return "Comment Characters Are Not E++";
    if (code == "F012") return "Word Is Too Long";
    if (code == "F013") return "Unexpected End Of Input Inside A Value";
    if (code == "F014") return "Invalid Escape Sequence";
    if (code == "F015") return "Lexer Could Not Build The Token Stream";
    return "Fatal Lexer Error";
}

const char* Lexer::catalogue_help(const std::string& code) {
    if (code == "E064") return "Close the note with ].";
    if (code == "F001") return "Pass the program as text (a string) to the lexer.";
    if (code == "F002") return "Split the program into smaller files.";
    if (code == "F003") return "E++ uses words for maths. Remove or replace this character.";
    if (code == "F004") return "Close the string, for example: say \"Hello\".";
    if (code == "F005") return "Close it, for example: say 'name'.";
    if (code == "F006") return "Put a variable name between the single quotes.";
    if (code == "F007") return "Unterminated notes are general program errors and use E064.";
    if (code == "F008") return "Write notes like this: note [Your note]";
    if (code == "F009") return "Remove the invisible NUL character (it usually arrives from a binary file).";
    if (code == "F010") return "Write numbers as digits, for example 42 or 3.5.";
    if (code == "F011") return "E++ notes do not use // or #. Use: note [Your note]";
    if (code == "F012") return "Keep words to 256 characters or fewer.";
    if (code == "F013") return "Finish the value before the line or the program ends.";
    if (code == "F014") return "E++ understands the escapes for a new line, a tab, a double quote and a backslash inside double quotes.";
    if (code == "F015") return "This is a bug in E++: report it with the program that caused it.";
    return "Check the program and try again.";
}

void Lexer::report_error(const std::string& message, int l, int c, const std::string& code) {
    if (!failed) {
        issue.message = message;
        issue.code = code;
        issue.name = catalogue_name(code);
        issue.help = catalogue_help(code);
        issue.line = l;
        issue.col = c;
        failed = true;
    }
}

// Record a fatal issue using the catalogue's own wording.
void Lexer::report_catalogue(const std::string& code, int l, int c) {
    report_error(std::string(catalogue_name(code)) + ".", l, c, code);
}

bool Lexer::is_at_end() const {
    return cursor >= src.size();
}

char Lexer::peek() const {
    if (is_at_end()) return '\0';
    return src[cursor];
}

char Lexer::peek_next() const {
    if (cursor + 1 >= src.size()) return '\0';
    return src[cursor + 1];
}

char Lexer::advance() {
    if (is_at_end()) return '\0';
    char c = src[cursor++];
    if (c == '\n') {
        line++;
        col = 1;
    } else {
        col++;
    }
    return c;
}

bool Lexer::match(char expected) {
    if (is_at_end() || src[cursor] != expected) return false;
    advance();
    return true;
}

void Lexer::skip_whitespace_and_comments() {
    while (!is_at_end()) {
        char c = peek();
        if (c == ' ' || c == '\t' || c == '\r') {
            advance();
        } else if (c == '/' && peek_next() == '/') {
            report_error("E++ does not use // comments. Use note [text].", line, col, "F011");
            return;
        } else if (c == '#') {
            report_error("E++ does not use # comments. Use note [text].", line, col, "F011");
            return;
        } else {
            break;
        }
    }
}

static bool is_py_block_header(const std::string& s, size_t pos) {
    auto skip_ws = [&](size_t& p) {
        while (p < s.size() && (s[p] == ' ' || s[p] == '\t')) p++;
    };
    auto match_kw = [&](size_t& p, const std::string& kw) -> bool {
        skip_ws(p);
        if (p + kw.size() <= s.size()) {
            std::string sub = s.substr(p, kw.size());
            for (char& ch : sub) ch = std::tolower(ch);
            if (sub == kw) {
                size_t after = p + kw.size();
                if (after == s.size() || !isalnum(static_cast<unsigned char>(s[after]))) {
                    p = after;
                    return true;
                }
            }
        }
        return false;
    };
    match_kw(pos, "run");
    match_kw(pos, "the");
    if (!match_kw(pos, "python")) return false;
    if (!match_kw(pos, "code")) return false;
    skip_ws(pos);
    if (pos < s.size() && s[pos] == ':') {
        pos++;
        skip_ws(pos);
        if (pos < s.size() && s[pos] == '\n') {
            return true;
        }
    }
    return false;
}

std::vector<Token> Lexer::tokenize() {
    // F001: the lexer was handed something that is not a program. The C++
    // constructor always receives a string, but the browser ABI can hand over
    // a null or missing buffer, so both builds check first.
    if (source_invalid) {
        report_catalogue("F001", 1, 1);
#ifndef EPP_BROWSER_PLAINTEXT
        throw LexError(issue.message, issue.line, issue.col, issue.code, issue.name, issue.help);
#else
        return {};
#endif
    }
    // F002: a program this large is not a program anyone typed.
    if (src.size() > MAX_SOURCE_LENGTH) {
        report_error("This program is larger than the 4 MB the lexer will read.", 1, 1, "F002");
#ifndef EPP_BROWSER_PLAINTEXT
        throw LexError(issue.message, issue.line, issue.col, issue.code, issue.name, issue.help);
#else
        return {};
#endif
    }
    // F009: a NUL byte means this is not text. Report the line it is on.
    for (size_t n = 0; n < src.size(); n++) {
        if (src[n] == '\0') {
            int nul_line = 1, nul_col = 1;
            for (size_t m = 0; m < n; m++) {
                if (src[m] == '\n') { nul_line++; nul_col = 1; } else { nul_col++; }
            }
            report_error("This line contains a NUL character (code 0), which is not part of an E++ program.",
                         nul_line, nul_col, "F009");
#ifndef EPP_BROWSER_PLAINTEXT
            throw LexError(issue.message, issue.line, issue.col, issue.code, issue.name, issue.help);
#else
            return {};
#endif
        }
    }

    std::vector<Token> tokens;
    while (!is_at_end()) {
        skip_whitespace_and_comments();
        if (failed || is_at_end()) break;

        char c = peek();
        if (c == '\n') {
            int start_line = line;
            int start_col = col;
            advance();
            // Don't add duplicate newlines
            if (!tokens.empty() && tokens.back().type != TokenType::TOKEN_NEWLINE) {
                tokens.emplace_back(TokenType::TOKEN_NEWLINE, "\n", start_line, start_col);
            }
            continue;
        }

        // Check for dedicated raw Python block
        if (is_py_block_header(src, cursor)) {
            int start_l = line;
            int start_c = col;
            while (!is_at_end() && peek() != '\n') advance();
            if (!is_at_end() && peek() == '\n') advance();

            tokens.emplace_back(TokenType::KW_RUN, "run", start_l, start_c);
            tokens.emplace_back(TokenType::KW_PYTHON, "python", start_l, start_c);
            tokens.emplace_back(TokenType::KW_CODE, "code", start_l, start_c);
            tokens.emplace_back(TokenType::TOKEN_COLON, ":", start_l, start_c);
            tokens.emplace_back(TokenType::TOKEN_NEWLINE, "\n", start_l, start_c);

            std::string py_block = "";
            int py_start_line = line;

            while (!is_at_end()) {
                size_t temp = cursor;
                while (temp < src.size() && (src[temp] == ' ' || src[temp] == '\t')) temp++;
                size_t indent_len = temp - cursor;
                if (temp < src.size() && src[temp] != '\n' && src[temp] != '\r') {
                    size_t w_end = temp;
                    while (w_end < src.size() && (isalnum(static_cast<unsigned char>(src[w_end])) || src[w_end] == '_')) w_end++;
                    std::string first_w = src.substr(temp, w_end - temp);
                    for (char& ch : first_w) ch = std::tolower(ch);
                    if (indent_len == 0 && (first_w == "say" || first_w == "tell" || first_w == "let" ||
                        first_w == "set" || first_w == "define" || first_w == "ask" || first_w == "add" ||
                        first_w == "note" || first_w == "run" || first_w == "if" || first_w == "otherwise")) {
                        break;
                    }
                }
                while (!is_at_end() && peek() != '\n') {
                    py_block += advance();
                }
                if (!is_at_end() && peek() == '\n') {
                    py_block += advance();
                }
            }

            Token tok(TokenType::TOKEN_PYTHON_BLOCK, py_block, py_start_line, 1);
            tok.string_value = py_block;
            tokens.push_back(tok);
            continue;
        }

        Token token = scan_token();
        if (failed) break;
        tokens.push_back(std::move(token));
    }

    // F015: the token stream is only trustworthy when the scan ended cleanly.
    // Two things would mean it did not: a failure was flagged without a reason
    // being recorded, or the loop stopped with source left unread (a scan
    // function that forgot to advance). Both are E++ bugs, and both are
    // reported as one instead of handing the parser a broken token stream.
    if (!failed && !is_at_end()) {
        report_catalogue("F015", line, col);
    }
    if (failed && issue.code.empty()) {
        report_catalogue("F015", line, col);
    }

    if (failed) {
#ifndef EPP_BROWSER_PLAINTEXT
        throw LexError(issue.message, issue.line, issue.col, issue.code, issue.name, issue.help);
#else
        return {};
#endif
    }
    tokens.emplace_back(TokenType::TOKEN_EOF, "", line, col);
    return tokens;
}

Token Lexer::scan_token() {
    skip_whitespace_and_comments();
    int start_line = line;
    int start_col = col;
    char c = advance();

    switch (c) {
        case ',': return Token(TokenType::TOKEN_COMMA, ",", start_line, start_col);
        case '(': return Token(TokenType::TOKEN_LPAREN, "(", start_line, start_col);
        case ')': return Token(TokenType::TOKEN_RPAREN, ")", start_line, start_col);
        case ':': return Token(TokenType::TOKEN_COLON, ":", start_line, start_col);
        case '!': return Token(TokenType::TOKEN_EXCLAMATION, "!", start_line, start_col);
        case '?': return Token(TokenType::TOKEN_QUESTION, "?", start_line, start_col);
        case '+': return Token(TokenType::TOKEN_PLUS_SYM, "+", start_line, start_col);
        case '-': return Token(TokenType::TOKEN_MINUS_SYM, "-", start_line, start_col);
        case '*': return Token(TokenType::TOKEN_STAR_SYM, "*", start_line, start_col);
        case '/': return Token(TokenType::TOKEN_SLASH_SYM, "/", start_line, start_col);
        case '%': return Token(TokenType::TOKEN_PERCENT_SYM, "%", start_line, start_col);

        case '"': {
            cursor--; // rewind
            col--;
            return scan_string();
        }
        case '\'': {
            cursor--; // rewind
            col--;
            return scan_variable();
        }

        default: {
            if (std::isdigit(static_cast<unsigned char>(c))) {
                cursor--; // rewind
                col--;
                return scan_number();
            }
            if (std::isalpha(static_cast<unsigned char>(c)) || c == '_') {
                cursor--; // rewind
                col--;
                return scan_word();
            }

            // F003: a character the lexer cannot make sense of. Handing it
            // on as an identifier would only confuse the parser later.
            report_error("Unexpected character \"" + std::string(1, c) +
                         "\". E++ uses words for operators (plus, minus, times...).",
                         start_line, start_col, "F003");
            return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
        }
    }
}

Token Lexer::scan_number() {
    int start_line = line;
    int start_col = col;
    std::string text;
    int decimals = 0;
    int stops = 0;

    while (!is_at_end() && std::isdigit(static_cast<unsigned char>(peek()))) {
        text.push_back(advance());
    }

    if (peek() == '.' && std::isdigit(static_cast<unsigned char>(peek_next()))) {
        text.push_back(advance()); // Consume '.'
        decimals++;
        while (!is_at_end() && std::isdigit(static_cast<unsigned char>(peek()))) {
            text.push_back(advance());
        }
    }

    // F010: a number with more than one decimal point, or a number so long it
    // cannot mean anything, is not a number. Both are fatal: what follows
    // would otherwise be read as a statement of its own.
    if (peek() == '.' && std::isdigit(static_cast<unsigned char>(peek_next()))) {
        report_error("This number has more than one decimal point. Write it as 2.5, not 2.5.5.",
                     start_line, start_col, "F010");
        return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
    }
    if (text.size() > 40) {
        report_error("This number has too many digits to be a number E++ can store.",
                     start_line, start_col, "F010");
        return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
    }
    (void)decimals; (void)stops;

    Token tok(TokenType::TOKEN_NUMBER, text, start_line, start_col);
    // strtod gives the same out-of-range behaviour in both builds without
    // requiring C++ exception support in WebAssembly.
    errno = 0;
    tok.number_value = std::strtod(text.c_str(), nullptr);
    if (errno == ERANGE) tok.number_value = 0.0;
    return tok;
}

Token Lexer::scan_string() {
    int start_line = line;
    int start_col = col;
    size_t start_pos = cursor;
    advance(); // Consume opening '"'
    std::string text;

    while (!is_at_end() && peek() != '"' && peek() != '\n') {
        char c = peek();
        if (c == '\\') {
            advance();
            if (is_at_end() || peek() == '\n') break;
            char esc = advance();
            if (esc == 'n') text.push_back('\n');
            else if (esc == 't') text.push_back('\t');
            else if (esc == 'r') text.push_back('\r');
            else if (esc == '"') text.push_back('"');
            else if (esc == '\\') text.push_back('\\');
            else text.push_back(esc);
        } else {
            text.push_back(advance());
        }
    }

    if (is_at_end() || peek() == '\n') {
        report_error("Unterminated string. Add the closing double quote (\").", start_line, start_col, "F004");
        return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
    }
    advance(); // closing double quote

    std::string raw_lexeme = src.substr(start_pos, cursor - start_pos);
    Token tok(TokenType::TOKEN_STRING, raw_lexeme, start_line, start_col);
    tok.string_value = text;
    return tok;
}

Token Lexer::scan_variable() {
    int start_line = line;
    int start_col = col;
    advance(); // Consume opening '\''
    std::string text;

    while (!is_at_end() && peek() != '\'' && peek() != '\n') {
        char c = advance();
        text.push_back(c);
    }

    if (is_at_end() || peek() == '\n') {
        report_error("Unterminated variable name. Add the closing single quote (').", start_line, start_col, "F005");
        return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
    }
    advance(); // closing single quote
    if (text.find_first_not_of(" \t\r") == std::string::npos) {
        report_error("A variable name cannot be empty.", start_line, start_col, "F006");
        return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
    }

    Token tok(TokenType::TOKEN_VARIABLE, "'" + text + "'", start_line, start_col);
    tok.string_value = text; // variable name
    return tok;
}

Token Lexer::scan_word() {
    int start_line = line;
    int start_col = col;
    std::string text;

    while (!is_at_end()) {
        char c = peek();
        if (std::isalnum(static_cast<unsigned char>(c)) || c == '_') {
            text.push_back(advance());
            // F012: no E++ word is this long, so stop rather than grow a
            // string without limit.
            if (text.size() > MAX_WORD_LENGTH) {
                report_error("This word is longer than the 256 characters a word may have.",
                             start_line, start_col, "F012");
                return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
            }
        } else {
            break;
        }
    }

    // Check for "it's"
    if (to_lower(text) == "it" && peek() == '\'' && (peek_next() == 's' || peek_next() == 'S')) {
        advance(); // consume '\''
        advance(); // consume 's'
        text = "it's";
    }

    std::string lower = to_lower(text);
    if (lower == "note") {
        // Must use note [Note]
        skip_whitespace_and_comments();
        if (peek() == '[') {
            advance(); // consume '['
            std::string note_text = "";
            while (!is_at_end() && peek() != ']' && peek() != '\n') {
                note_text += advance();
            }
            if (is_at_end() || peek() != ']') {
                report_error("Unterminated note. Close it with ].", start_line, start_col, "E064");
                return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
            }
            advance(); // consume ']'
            Token tok(TokenType::KW_NOTE, "note [" + note_text + "]", start_line, start_col);
            tok.string_value = note_text;
            return tok;
        } else {
            report_error("Notes must use the syntax: note [Note]", start_line, start_col, "F008");
            return Token(TokenType::TOKEN_EOF, "", start_line, start_col);
        }
    }

    auto it = keywords.find(lower);
    if (it != keywords.end()) {
        return Token(it->second, text, start_line, start_col);
    }

    // Unquoted identifier/word
    Token tok(TokenType::TOKEN_IDENTIFIER, text, start_line, start_col);
    tok.string_value = text;
    return tok;
}

std::string Lexer::token_type_name(TokenType t) {
    switch (t) {
        case TokenType::TOKEN_EOF: return "EOF";
        case TokenType::TOKEN_NEWLINE: return "NEWLINE";
        case TokenType::TOKEN_NUMBER: return "NUMBER";
        case TokenType::TOKEN_STRING: return "STRING";
        case TokenType::TOKEN_VARIABLE: return "VARIABLE";
        case TokenType::TOKEN_IDENTIFIER: return "IDENTIFIER";
        case TokenType::TOKEN_COMMA: return ",";
        case TokenType::TOKEN_LPAREN: return "(";
        case TokenType::TOKEN_RPAREN: return ")";
        case TokenType::TOKEN_COLON: return ":";
        case TokenType::TOKEN_EXCLAMATION: return "!";
        case TokenType::TOKEN_QUESTION: return "?";
        case TokenType::TOKEN_PLUS_SYM: return "+";
        case TokenType::TOKEN_MINUS_SYM: return "-";
        case TokenType::TOKEN_STAR_SYM: return "*";
        case TokenType::TOKEN_SLASH_SYM: return "/";
        case TokenType::TOKEN_PERCENT_SYM: return "%";
        case TokenType::KW_SAY: return "say";
        case TokenType::KW_TELL: return "tell";
        case TokenType::KW_LET: return "let";
        case TokenType::KW_BE: return "be";
        case TokenType::KW_SET: return "set";
        case TokenType::KW_TO: return "to";
        case TokenType::KW_ASK: return "ask";
        case TokenType::KW_AND: return "and";
        case TokenType::KW_SAVE: return "save";
        case TokenType::KW_THE: return "the";
        case TokenType::KW_OUTPUT: return "output";
        case TokenType::KW_ANSWER: return "answer";
        case TokenType::KW_RESULT: return "result";
        case TokenType::KW_AS: return "as";
        case TokenType::KW_IN: return "in";
        case TokenType::KW_ADD: return "add";
        case TokenType::KW_LIBRARY: return "library";
        case TokenType::KW_CHECK: return "check";
        case TokenType::KW_IF: return "if";
        case TokenType::KW_IS: return "is";
        case TokenType::KW_NOT: return "not";
        case TokenType::KW_A: return "a";
        case TokenType::KW_NUMBER: return "number";
        case TokenType::KW_PLUS: return "plus";
        case TokenType::KW_MINUS: return "minus";
        case TokenType::KW_TIMES: return "times";
        case TokenType::KW_MULTIPLIED: return "multiplied";
        case TokenType::KW_DIVIDED: return "divided";
        case TokenType::KW_BY: return "by";
        case TokenType::KW_MODULO: return "modulo";
        case TokenType::KW_MOD: return "mod";
        case TokenType::KW_CONCAT: return "concat";
        case TokenType::KW_IT: return "it";
        case TokenType::KW_WITH: return "with";
        case TokenType::KW_SEPARATION: return "separation";
        case TokenType::KW_METHOD: return "method";
        case TokenType::KW_OF: return "of";
        case TokenType::TOKEN_PYTHON_BLOCK: return "PYTHON_BLOCK";
        default: return "KEYWORD";
    }
}

} // namespace epp
