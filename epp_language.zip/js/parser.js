/*
 * E++ Parser.
 *
 * Consumes the lexer token stream and builds an AST (see ast.js).
 *
 * Grammar (statements end with a period '.' or a newline):
 *
 *   program        := statement*
 *   statement      := define | set | say | ask | wait | library
 *                   | if | repeat | while | stop | note
 *                   | increase | decrease | python
 *   define         := "Define" <name> "as" <expression>
 *   set            := ("Set"|"Change") <name> "to" <expression>
 *   say            := ("say"|"display"|"show") <expression>
 *   ask            := "ask" <expression> "and save answer as" <name>
 *   wait           := "wait" <expression>
 *   library        := "library" <STRING> ("add"|"load"|"import")
 *   increase       := "Increase" <name> "by" <expression>
 *   decrease       := "Decrease" <name> "by" <expression>
 *   python         := "python" "code" <STRING>                        [Python]
 *                     (a STRING starting with "-" is a raw multi-line
 *                      Python block, extracted by the parser before
 *                      lexing — the lexer is generic and never sees it)
 *   if             := "if" <condition> "then" <statement>
 *                     ["otherwise" <statement>]                        (inline)
 *                   | "if" <condition> "then" NEWLINE statement*
 *                     ["otherwise" statement*] "end if"                 (block)
 *                     — branches may chain without limit:
 *                       "otherwise if" <condition> "then" ... , and a
 *                       branch action may end with the word "and" to
 *                       continue the chain on the next line:
 *                         if <c> then <action> and
 *                         otherwise if <c> then <action> and
 *                         otherwise <action>
 *   repeat         := "repeat" <expression> "times" (statement | block "end repeat")
 *   while          := "while" <condition> "do" (statement | block "end while")
 *   condition      := <expression> [ ("is" ["not"] <comparison>) <expression> ]
 *                     comparisons include "equal to", "greater than",
 *                     "less than" / "lesser than", and the number tests
 *                     "is a number" / "is not a number". Inside an
 *                     otherwise-if chain, "not a number" on its own tests
 *                     the value the first condition in the chain tested.
 *   expression     := additive [ "as" ("fraction"|"decimal") ]
 *   additive       := multiplicative (("plus"|"minus") multiplicative)*
 *   multiplicative := power (("times"|"divided by"|"percent of") power)*
 *   power          := unary [ "power of" power ]
 *   unary          := ["minus"|"square root of"] unary | primary
 *   primary        := NUMBER | STRING | VARIABLE
 *                   | "(" expression ")"
 *                   | ("uppercase of"|"lowercase of"|"length of") unary   [Text]
 *                   | "random number between" power "and" power          [Random]
 *
 * Unquoted words are not values. Text must use double quotes and variable
 * references use single quotes, including in branches that never execute.
 *
 * Library gating: operators owned by a library (see libraries.js) raise a
 * LibraryError at parse time when the library has not been added earlier in
 * the program. `divided by` and `power of` are also listed in the basic
 * maths section of the spec; E++ follows the Math-library section and treats
 * them (with the other Math features) as unlocked by `library "Math" add`.
 */
(function (global) {
  'use strict';

  var EPP = global.EPP || (global.EPP = {});
  var ParseError = EPP.ParseError;
  var LibraryError = EPP.LibraryError;
  var LexError = EPP.LexError;

  // Words that can never be part of a bare-word value or expression.
  var RESERVED = {
    plus: 1, minus: 1, times: 1, divided: 1, by: 1, power: 1, percent: 1,
    square: 1, root: 1, of: 1, as: 1, is: 1, equal: 1, greater: 1, less: 1,
    than: 1, then: 1, otherwise: 1, 'if': 1, end: 1, repeat: 1, 'while': 1, forever: 1,
    'do': 1, and: 1, not: 1, different: 1, from: 1, between: 1, or: 1,
    contains: 1
  };

  /*
   * Dash-mode Python blocks (python code "-...") are taken out of the
   * source here, by the parser, before lexing. Everything between the
   * opening dash and the closing quote is raw Python: it may span lines
   * and contain characters E++ would reject, so it must never reach the
   * (fully generic, Python-agnostic) lexer. Each block is replaced in the
   * prepared source by a one-line placeholder string holding its index,
   * followed by the same number of newlines the block contained, so the
   * line numbers of all following E++ code stay correct. Strings, quoted
   * variables and comments are respected — the words `python code "-`
   * inside a string or a note do not start a block.
   *
   * Returns { source, blocks: [{ start, end, code, line, column, unterminated }] }
   * where start/end are offsets in the ORIGINAL source.
   */
  function extractPythonBlocks(source) {
    source = source === undefined || source === null ? '' : String(source);
    var blocks = [];
    var out = '';
    var i = 0;
    var line = 1, column = 1;
    var state = 'normal'; // normal | string | variable | comment
    var atStatementStart = true;

    function isWordChar(ch) { return !!ch && /[A-Za-z0-9_]/.test(ch); }
    function copyChar() {
      var ch = source[i];
      out += ch;
      if (ch === '\n') { line += 1; column = 1; } else { column += 1; }
      i += 1;
      return ch;
    }
    // If a `python code ",` or `python code "-` sequence starts at position p, returns the
    // index of its opening quote; otherwise returns -1.
    function rawPythonQuoteAt(p) {
      if (source.slice(p, p + 6).toLowerCase() !== 'python') return -1;
      if (isWordChar(source[p - 1]) || isWordChar(source[p + 6])) return -1;
      var j = p + 6;
      while (source[j] === ' ' || source[j] === '\t') j += 1;
      if (source.slice(j, j + 4).toLowerCase() !== 'code') return -1;
      if (isWordChar(source[j + 4])) return -1;
      j += 4;
      while (source[j] === ' ' || source[j] === '\t') j += 1;
      return (source[j] === '"' && (source[j + 1] === ',' || source[j + 1] === '-')) ? j : -1;
    }

    while (i < source.length) {
      var ch = source[i];

      if (state === 'comment') {
        if (ch === '\n') { state = 'normal'; atStatementStart = true; copyChar(); }
        else copyChar();
        continue;
      }
      if (state === 'string') {
        if (ch === '\\' && i + 1 < source.length) { copyChar(); copyChar(); continue; }
        if (ch === '"' || ch === '\n') state = 'normal';
        copyChar();
        continue;
      }
      if (state === 'variable') {
        if (ch === "'" || ch === '\n') state = 'normal';
        copyChar();
        continue;
      }

      // normal state
      if (ch === '\n' || ch === '.' || ch === ';') { atStatementStart = true; copyChar(); continue; }
      if (ch === '#') { state = 'comment'; copyChar(); continue; }
      if (ch === '/' && source[i + 1] === '/') { state = 'comment'; copyChar(); continue; }
      if (ch === '"') { state = 'string'; atStatementStart = false; copyChar(); continue; }
      if (ch === "'") { state = 'variable'; atStatementStart = false; copyChar(); continue; }
      if (atStatementStart && source.slice(i, i + 4).toLowerCase() === 'note' && !isWordChar(source[i + 4])) {
        state = 'comment'; copyChar(); continue;
      }

      var quoteIndex = rawPythonQuoteAt(i);
      if (quoteIndex !== -1) {
        // Copy `python code ` up to the quote, remembering its position.
        while (i < quoteIndex) copyChar();
        var quoteLine = line, quoteColumn = column;
        var modeChar = source[quoteIndex + 1]; // ',' (Humanizer) or '-' (legacy)
        var terminatorStr = modeChar + '"';    // ',"' or '-"'
        var delimEnd = source.indexOf(terminatorStr, quoteIndex + 2);
        var closeIndex = delimEnd === -1 ? source.indexOf('"', quoteIndex + 2) : delimEnd;
        var unterminated = closeIndex === -1;
        var codeEnd = unterminated ? source.length : closeIndex;
        var blockEnd = unterminated ? source.length : closeIndex + (delimEnd === -1 ? 1 : 2);
        var code = source.slice(quoteIndex + 2, codeEnd);
        var segment = source.slice(quoteIndex, blockEnd);
        var newlines = 0;
        for (var k = 0; k < segment.length; k++) if (segment[k] === '\n') newlines += 1;
        blocks.push({
          start: quoteIndex, end: blockEnd, code: code,
          line: quoteLine, column: quoteColumn, unterminated: unterminated,
          modeChar: modeChar
        });
        out += '"\u0001' + (blocks.length - 1) + '\u0001"';
        for (var n = 0; n < newlines; n++) out += '\n';
        // Advance position/line/column past the original block.
        for (var m = 0; m < segment.length; m++) {
          if (segment[m] === '\n') { line += 1; column = 1; } else { column += 1; }
        }
        i = blockEnd;
        atStatementStart = false;
        continue;
      }

      if (ch !== ' ' && ch !== '\t' && ch !== '\r') atStatementStart = false;
      copyChar();
    }
    return { source: out, blocks: blocks };
  }

  function Parser(source, options) {
    var Lexer = EPP.Lexer;
    var prepared = extractPythonBlocks(source);
    this.pythonBlocks = prepared.blocks;
    for (var b = 0; b < prepared.blocks.length; b++) {
      if (prepared.blocks[b].unterminated) {
        var term = prepared.blocks[b].modeChar === ',' ? ',"' : '"';
        throw EPP.Errors.error('E064', 'The Python code block never ends. Its closing ' + term + ' is missing.',
          prepared.blocks[b].line, prepared.blocks[b].column,
          'Close the Python code with ' + term + ' at the end of the block.');
      }
    }
    this.tokens = new Lexer(prepared.source).tokenize().filter(function (t) { return t.type !== 'COMMENT'; });
    this.pos = 0;
    this.loadedLibraries = {}; // canonical name -> true, in source order
    this.usedFeatures = [];    // every library feature the source actually uses
    this.options = options || {};
  }

  // ---------- token helpers ----------
  Parser.prototype.current = function () { return this.tokens[this.pos]; };
  Parser.prototype.peek = function (offset) { return this.tokens[this.pos + (offset || 0)]; };
  Parser.prototype.atEnd = function () { return this.current().type === 'EOF'; };
  Parser.prototype.advance = function () { return this.tokens[this.pos++]; };
  Parser.prototype.isSeparator = function (token) {
    return token && (token.type === 'NEWLINE' || token.type === 'PERIOD' || token.type === 'SEMICOLON');
  };
  Parser.prototype.skipSeparators = function () {
    while (this.isSeparator(this.current())) this.advance();
  };
  Parser.prototype.isWord = function (word, token) {
    var t = token || this.current();
    return t && t.type === 'WORD' && t.value.toLowerCase() === word;
  };
  Parser.prototype.matchWord = function (word) {
    if (this.isWord(word)) { this.advance(); return true; }
    return false;
  };
  Parser.prototype.expectWord = function (word, context) {
    var t = this.current();
    if (!this.isWord(word)) {
      // 1.4: say which kind of nothing this is - the line ended, or the
      // whole program did - instead of a flat "unexpected word".
      if (t.type === 'NEWLINE') {
        throw new ParseError('Expected the word "' + word + '"' + (context ? ' ' + context : '') +
          ', but the line ended first.', t.line, t.column,
          'Finish the sentence on one line, or continue it below.', 'E063');
      }
      if (t.type === 'EOF') {
        throw new ParseError('Expected the word "' + word + '"' + (context ? ' ' + context : '') +
          ', but the program ended first.', t.line, t.column,
          'Finish the idea: a value, a condition or a block ending is missing.', 'E064');
      }
      throw new ParseError(
        'Expected the word "' + word + '"' + (context ? ' ' + context : '') + ' but found ' + this.describe(t) + '.',
        t.line, t.column,
        'Check the sentence structure — E++ statements read like English sentences.'
      , 'E062');
    }
    return this.advance();
  };
  Parser.prototype.expect = function (type, what) {
    var t = this.current();
    if (t.type !== type) {
      if (type === 'RPAREN') {
        throw new ParseError('Expected ' + what + ' but found ' + this.describe(t) + '.', t.line, t.column,
          'Add the closing ) where the maths ends.', 'E065');
      }
      throw new ParseError('Expected ' + what + ' but found ' + this.describe(t) + '.', t.line, t.column, null, 'E062');
    }
    return this.advance();
  };
  Parser.prototype.describe = function (token) {
    if (!token || token.type === 'EOF') return 'the end of the program';
    if (token.type === 'NEWLINE') return 'the end of the line';
    if (token.type === 'PERIOD') return '"."';
    return '"' + token.raw + '"';
  };

  Parser.prototype.requireLibrary = function (feature, token) {
    if (!EPP.Libraries) return;
    // A feature appearing in the source is a use of its library (W003).
    this.usedFeatures.push(feature);
    // A feature may belong to more than one library (ImprovedWait contains
    // every ImprovedWaitLite feature, for example) — any added owner is enough.
    var owners = EPP.Libraries.ownersOf
      ? EPP.Libraries.ownersOf(feature)
      : (EPP.Libraries.ownerOf(feature) ? [EPP.Libraries.ownerOf(feature)] : []);
    if (!owners.length) return;
    for (var i = 0; i < owners.length; i++) {
      if (this.loadedLibraries[owners[i]]) return;
    }
    var owner = owners[0];
    var why = EPP.Libraries.whyUnavailable ? EPP.Libraries.whyUnavailable(owner) : null;
    throw new LibraryError(
      '"' + feature + '" belongs to the ' + owner + ' library, which has not been added yet.',
      token.line, token.column,
      why || ('Add this near the top of your program: add library "' + owner + '"')
    , 'E042');
  };

  // ---------- program & statements ----------
  Parser.prototype.parse = function () {
    var body = [];
    this.skipSeparators();
    while (!this.atEnd()) {
      if (this.isWord('end') || this.isWord('otherwise')) {
        var t = this.current();
        if (t.value.toLowerCase() === 'otherwise') {
          throw new ParseError("'otherwise' needs an if above it: otherwise comes straight after its if.",
            t.line, t.column,
            'Put otherwise immediately after the if it belongs to.', 'E022');
        }
        throw new ParseError('Unexpected "' + t.value + '" here — there is no matching opening statement.',
          t.line, t.column, 'Remove it, or add the "if"/"repeat"/"while" statement it belongs to.', 'E017');
      }
      body.push(this.parseStatement());
      this.skipSeparators();
    }
    return EPP.AST.Program(body);
  };

  Parser.prototype.parseStatement = function () {
    var t = this.current();
    // A stray otherwise/else at the top of a statement is E022 (it has no if),
    // which reads better than the generic "unexpected ending" of E017.
    if (t.type === 'WORD' && (t.value.toLowerCase() === 'otherwise' || t.value.toLowerCase() === 'else')) {
      throw new ParseError("'" + t.value + "' needs an if above it. An if is closed by its own ending, and otherwise comes straight after it.",
        t.line, t.column,
        'Put otherwise immediately after the if it belongs to: if ... then ... / otherwise ...', 'E022');
    }
    // A statement starting with a quoted name is a Draw movement:
    // 'hero' move up "10"
    if (t.type === 'VARIABLE') throw new LibraryError('Sprite movement is only available in E++ Studio.', t.line, t.column);
    if (t.type !== 'WORD') {
      // A statement may also start with a value-less token error:
      throw new ParseError('Expected a statement but found ' + this.describe(t) + '.',
        t.line, t.column,
        'Statements start with a word such as Define, say, ask, if, wait, add library or python code.', 'E015');
    }
    var word = t.value.toLowerCase();
    switch (word) {
      case 'add': return this.parseAdd();
      // `let` and `define` are the same statement, and `be`, `to` and `as` are
      // the same connector: the Studio's examples say `let 'Grade' be 29`.
      case 'define': case 'let': return this.parseDefine();
      case 'set': case 'change': return this.parseSet();
      case 'say': case 'display': case 'show': return this.parseSay();
      case 'print':
        // print("...") is Python, not E++ — it must never quietly behave
        // like `say`. Python may only run inside python code "...", and
        // only after the Python library has been added.
        throw new ParseError('\"' + t.value + '\" is Python, not E++, so E++ will not run it on its own.',
          t.line, t.column,
          'To run Python, first add the Python library with: add library \"Python\" — then put the Python inside python code, like this: python code \"print(1)\". If you just want E++ to show something, use the word say.', 'E048');
      case 'ask': return this.parseAsk();
      case 'wait':
      case 'sleep': return this.parseWait();
      case 'create': return this.parseCreateActor();
      // link the image "hero.png" to the actor 'hero'
      case 'link': return this.parseActorImage();
      case 'put': return this.parsePlaceActor();
      case 'play': return this.parsePlayGame();
      case 'pause': return this.parseActorControl('pause');
      case 'resume': return this.parseActorControl('resume');
      case 'cancel': return this.parseCancelWait();
      // Release 1.5a1 — the other half of file handling: removing a file.
      case 'delete': return this.parseDeleteFile();
      case 'remove': return this.parseDeleteFile();
      case 'library': return this.parseLibrary();
      case 'if': return this.parseIf();
      // The same list twice: one for each spelling. Both are E022.
      // eslint-disable-next-line no-fallthrough
      case 'otherwise': case 'else': {
        throw new ParseError("'" + t.value + "' needs an if above it. An if is closed by its own ending, and otherwise comes straight after it.",
          t.line, t.column,
          'Put otherwise immediately after the if it belongs to: if ... then ... / otherwise ...', 'E022');
      }
      case 'repeat': return this.parseRepeat();
      case 'while': return this.parseWhile();
      case 'forever': return this.parseForever();
      case 'stop': return this.parseStop(t);
      case 'break': this.advance(); return EPP.AST.Stop(t);
      case 'note': return this.parseNote();
      case 'increase': return this.parseIncreaseDecrease(true);
      case 'decrease': return this.parseIncreaseDecrease(false);
      case 'python': return this.parsePython();
      case 'loopback': return this.parseLoopback();
      case 'check': return this.parseCheck();
      default:
        throw new ParseError('I do not understand the statement starting with "' + t.value + '".',
          t.line, t.column,
          'Statements start with Define, say, display, ask, if, Increase, Decrease, repeat, while, wait, python code or add library "..."', 'E015');
    }
  };

  Parser.prototype.parseAdd = function () {
    var kw = this.advance(); // add
    // Release 1.2: `add the "Math" library` is the form the documentation
    // uses, so accept it alongside `add library "Math"`.
    if (this.isWord('the') && this.peek(1) && this.peek(1).type === 'STRING') {
      this.advance(); // the
      var libToken = this.advance(); // "Math"
      this.expectWord('library', 'after the library name, for example: add the "Math" library.');
      return this.finishAdd(libToken, kw);
    }
    if (this.isWord('library')) {
      this.advance(); // library
      var nameToken = this.current();
      if (nameToken.type !== 'STRING') {
        throw new ParseError('A library name must be written in double quotes, for example: add library "Math".',
          nameToken.line, nameToken.column, null, 'E044');
      }
      this.advance();
      if (this.options && this.options.fileName) {
        var fname = this.options.fileName;
        if (/\.eppl$/i.test(fname) && !/\.eppla$/i.test(fname)) {
          throw new LibraryError(
            'Files ending in .eppl cannot use libraries: a file that uses a library is an .eppla file.',
            nameToken.line, nameToken.column,
            'Rename this file to "' + fname.replace(/\.eppl$/i, '.eppla') + '" to use libraries.', 'E046');
        }
      }
      return this.finishAdd(nameToken, kw);
    }
    var t = this.current();
    throw new ParseError('Expected "library" after "add" but found ' + this.describe(t) + '.',
      kw.line, kw.column, 'To add a library, write: add the "Math" library.', 'E045');
  };

  /** Shared tail of every way of writing "add a library". */
  Parser.prototype.finishAdd = function (nameToken, kw) {
    if (!EPP.Libraries || !EPP.Libraries.isKnown(nameToken.value)) {
      var available = EPP.Libraries ? EPP.Libraries.names().join(', ') : 'Math';
      throw new LibraryError('There is no library called "' + nameToken.value + '".',
        nameToken.line, nameToken.column, 'Available libraries: ' + available + '.', 'E043');
    }
    var canonical = EPP.Libraries.canonical(nameToken.value);
    if (EPP.Libraries.isAvailable && !EPP.Libraries.isAvailable(canonical)) {
      throw new LibraryError('The "' + canonical + '" library is not included in this build of E++.',
        nameToken.line, nameToken.column,
        EPP.Libraries.whyUnavailable(canonical), EPP.Libraries.errorCode(canonical));
    }
    if (this.options && this.options.fileName) {
      var fname2 = this.options.fileName;
      if (/\.eppl$/i.test(fname2) && !/\.eppla$/i.test(fname2)) {
        throw new LibraryError(
          'Files ending in .eppl cannot use libraries: a file that uses a library is an .eppla file.',
          nameToken.line, nameToken.column,
          'Rename this file to "' + fname2.replace(/\.eppl$/i, '.eppla') + '" to use libraries.', 'E046');
      }
    }
    this.loadedLibraries[canonical] = true;
    return EPP.AST.Library(canonical, kw);
  };

  Parser.prototype.parseName = function (context) {
    var t = this.current();
    if (t.type !== 'WORD') {
      throw new ParseError('Expected a variable name ' + context + ' but found ' + this.describe(t) + '.',
        t.line, t.column, 'Variable names are single words, for example: name, score, answer2.', 'E030');
    }
    this.advance();
    return t.value;
  };

  Parser.prototype.parseDefine = function () {
    var kw = this.advance(); // Define
    // `Define x as 1` is legal E++ (a name is its own quotes-free word), but
    // `Define "x" as 1` is not: double quotes make it text. That mistake is
    // E036, with the single-quoted fix written out.
    if (this.current().type === 'STRING') {
      var unquoted = this.current();
      throw new ParseError(
        '"' + unquoted.value + '" is text, not a variable name. Variables are written inside single quotes: ' +
        '\'' + unquoted.value + '\'',
        unquoted.line, unquoted.column,
        'Variables use single quotes and text uses double quotes.', 'E036');
    }
    // Quoted variable name form: define '<name>' as <value>
    // Also: define '<name>' as drawing sprite  (Draw library)
    // Also: define '<name>' as image "<filename>"  (Image library)
    if (this.current().type === 'VARIABLE') {
      var quotedName = this.advance().value;
      var quotedConnector = 'in a definition, for example: define \'' + quotedName + '\' as ...';
      if (!this.matchWord('as') && !this.matchWord('be') && !this.matchWord('to')) {
        var connector = this.current();
        throw new ParseError('Expected the word "as" after ' + quotedName + ' but found ' + this.describe(connector) + '.',
          connector.line, connector.column, quotedConnector, 'E062');
      }
      // Draw is not shipped in the standalone runtime.
      if (this.isWord('drawing')) throw new LibraryError('The Draw library is only available in E++ Studio.', kw.line, kw.column);
      // Check for "image <source>" (Image library)
      if (this.isWord('image')) {
        this.requireLibrary('define image', kw);
        this.advance(); // image
        if (this.isSeparator(this.current()) || this.atEnd()) {
          var badImg = this.current();
          throw new ParseError('Expected a Base64 image string after "image" in the definition.',
            badImg.line, badImg.column,
            'Write it like this: define \'' + quotedName + '\' as image "<base64-string>".', 'E003');
        }
        var source = this.parseExpression();
        return EPP.AST.DefineImage(quotedName, source, kw);
      }
      // 1.4: a definition with no value is E031, not a bare "missing value".
      if (this.isSeparator(this.current()) || this.atEnd()) {
        var noValue = this.current();
        throw new ParseError('This definition has no value: ' + quotedName + ' needs something after "be".',
          noValue.line, noValue.column,
          "Give the variable a value, for example: let '" + quotedName + "' be 0", 'E031');
      }
      // Dev Build 5: regular variable definition with quoted name
      var value = this.parseExpression();
      return EPP.AST.Define(quotedName, value, kw);
    }
    var name = this.parseName('after "Define"');
    this.expectWord('as', 'in a Define statement, for example: Define ' + name + ' as 10.');
    if (this.isSeparator(this.current()) || this.atEnd()) {
      var noValue2 = this.current();
      throw new ParseError('This definition has no value: ' + name + ' needs something after "as".',
        noValue2.line, noValue2.column,
        'Give the variable a value, for example: Define ' + name + ' as 10.', 'E031');
    }
    var value = this.parseExpression();
    return EPP.AST.Define(name, value, kw);
  };

  /** loopback to if — re-evaluates the nearest previous if (Dev Build 4). */
  Parser.prototype.parseLoopback = function () {
    var kw = this.advance(); // loopback
    if (!this.matchWord('to')) {
      var bad = this.current();
      throw new ParseError('Expected "to" after "loopback" but found ' + this.describe(bad) + '.',
        bad.line, bad.column, 'Write it like this: loopback to if', 'E062');
    }
    if (!this.matchWord('if')) {
      var bad2 = this.current();
      throw new ParseError('Expected "if" after "loopback to" but found ' + this.describe(bad2) + '.',
        bad2.line, bad2.column, 'loopback only goes back to an if, so write it like this: loopback to if', 'E062');
    }
    return EPP.AST.Loopback(kw);
  };

  /**
   * Dev Build 5: check if '<variable>' exists — Image library.
   * Checks whether an image variable has been defined.
   */
  Parser.prototype.parseCheck = function () {
    var kw = this.advance(); // check
    this.requireLibrary('check if exists', kw);
    if (!this.matchWord('if')) {
      var badIf = this.current();
      throw new ParseError('Expected "if" after "check" but found ' + this.describe(badIf) + '.',
        badIf.line, badIf.column, 'Write it like this: check if \'cat\' exists.', 'E062');
    }
    // Expect a variable reference (quoted name)
    var varToken = this.current();
    if (varToken.type !== 'VARIABLE') {
      throw new ParseError('Expected a variable name in single quotes after "if" but found ' + this.describe(varToken) + '.',
        varToken.line, varToken.column, 'Write it like this: check if \'cat\' exists.', 'E030');
    }
    this.advance(); // consume the variable token
    if (!this.matchWord('exists')) {
      var badExists = this.current();
      throw new ParseError('Expected "exists" after the variable but found ' + this.describe(badExists) + '.',
        badExists.line, badExists.column, 'Write it like this: check if \'cat\' exists.', 'E062');
    }
    return EPP.AST.CheckExists(varToken.value, kw);
  };

  Parser.prototype.parseSet = function () {
    var kw = this.advance(); // Set / Change

    // set the image of the actor 'hero' to "<source>"
    if (this.isWord('the') && this.isWord('image', this.peek(1))) {
      return this.parseActorImage(kw);
    }

    // Release 1.2: settings that belong to the Game library.
    if (this.isWord('the') && this.isWord('game', this.peek(1))) {
      this.requireLibrary('set the game window', kw);
      this.advance(); // the
      this.advance(); // game
      if (this.matchWord('window')) {
        this.expectWord('to', 'in "set the game window to 640 by 480".');
        var width = this.parseExpression();
        this.expectWord('by', 'between the width and the height, for example: set the game window to 640 by 480.');
        var height = this.parseExpression();
        return EPP.AST.GameWindow(width, height, kw);
      }
      if (this.matchWord('background')) {
        this.expectWord('to', 'in "set the game background to \"night\"".');
        return EPP.AST.GameBackground(this.parseExpression(), kw);
      }
      var badGame = this.current();
      throw new ParseError('Expected "window" or "background" after "set the game" but found ' + this.describe(badGame) + '.',
        badGame.line, badGame.column,
        'Write it like this: set the game window to 640 by 480 — or: set the game background to "night".', 'E062');
    }

    // set "score" to 3 — double quotes make the name text, not a variable.
    if (this.current().type === 'STRING') {
      var quotedName = this.current();
      throw new ParseError('"' + quotedName.value + '" is text, not a variable name. Variables are written inside ' +
        'single quotes: set \'' + quotedName.value + '\' to ...',
        quotedName.line, quotedName.column,
        'Variables use single quotes and text uses double quotes.', 'E036');
    }

    // set the size of the actor 'hero' to 2
    if (this.isWord('the') && this.isWord('size', this.peek(1))) {
      this.requireLibrary('set the size of the actor', kw);
      this.advance(); // the
      this.advance(); // size
      this.expectWord('of', 'in "set the size of the actor \'hero\' to 2".');
      this.matchWord('the');
      if (!this.matchWord('actor')) {
        var badSize = this.current();
        throw new ParseError('Expected the word "actor" after "the size of" but found ' + this.describe(badSize) + '.',
          badSize.line, badSize.column,
          'Write it like this: set the size of the actor \'hero\' to 2', 'E062');
      }
      var sizeName = this.current();
      if (sizeName.type !== 'VARIABLE') {
        throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(sizeName) + '.',
          sizeName.line, sizeName.column,
          'Write it like this: set the size of the actor \'hero\' to 2', 'E030');
      }
      this.advance();
      this.expectWord('to', 'before the size, for example: set the size of the actor \'hero\' to 2.');
      return EPP.AST.ActorSize(sizeName.value, this.parseExpression(), kw);
    }

    var name;
    // Dev Build 5: Set also accepts a quoted variable name: Set 'count' to 5.
    if (this.current().type === 'VARIABLE') {
      name = this.advance().value;
    } else {
      name = this.parseName('after "' + kw.value + '"');
    }
    this.expectWord('to', ', for example: Set ' + name + ' to 5.');
    var value = this.parseExpression();
    return EPP.AST.Set(name, value, kw);
  };

  Parser.prototype.parseSay = function () {
    var kw = this.advance(); // say / display / show
    if (this.isSeparator(this.current()) || this.atEnd()) {
      throw new ParseError('"' + kw.value + '" needs something after it.', kw.line, kw.column,
        'For example: ' + kw.value + ' "Hello". or ' + kw.value + ' 1 plus 1.', 'E003');
    }
    // Release 1.2: show the actor 'hero' / hide the actor 'hero' (Game library)
    if (this.isWord('the') && this.isWord('actor', this.peek(1)) && this.peek(2) &&
        this.peek(2).type === 'VARIABLE') {
      var action = kw.value.toLowerCase();
      if (action === 'show' || action === 'hide') {
        this.requireLibrary(action + ' the actor', kw);
        this.advance(); // the
        this.advance(); // actor
        var actorName = this.advance().value;
        return EPP.AST.ActorAction(actorName, action, kw);
      }
    }

    // Dev Build 5: display image '<name>' — Image library
    if (this.isWord('image') && this.peek(1) && this.peek(1).type === 'VARIABLE') {
      this.requireLibrary('display image', kw);
      this.advance(); // image
      var imgName = this.advance().value; // 'name'
      return EPP.AST.DisplayImage(imgName, kw);
    }
    var parts = [this.parseExpression()];
    while (this.current() && this.current().type === 'COMMA') {
      this.advance(); // ,
      parts.push(this.parseExpression());
    }
    return EPP.AST.Say(parts[0], kw, parts.length > 1 ? parts : null);
  };

  Parser.prototype.parseAsk = function () {
    var kw = this.advance(); // ask
    var prompt = this.parseExpression();
    // and save answer as <name>   (a few words may be omitted, kept forgiving)
    this.expectWord('and', 'in an ask statement, for example: ask "Your name?" and save answer as name.');
    this.matchWord('save');
    // `save the output as`, `save it as`, `save answer as` and `save as` all
    // mean the same thing; read past the filler words to the name.
    while (!this.isWord('as') &&
           (this.isWord('the') || this.isWord('output') || this.isWord('answer') ||
            this.isWord('result') || this.isWord('it'))) {
      this.advance();
    }
    this.expectWord('as', 'before the variable name.');
    // Dev Build 5: ask also accepts a quoted variable name: ask "..." and save answer as 'name'.
    var name;
    if (this.current().type === 'VARIABLE') {
      name = this.advance().value;
    } else {
      name = this.parseName('at the end of the ask statement');
    }
    return EPP.AST.Ask(prompt, name, kw);
  };

  /**
   * Release 1.2 — wait, grown up.
   *
   *   wait 2 seconds                          classic wait
   *   wait 2 seconds as 'intro'               named wait           [ImprovedWaitLite]
   *   wait 2 seconds and then say "Done!"     wait, then do this   [ImprovedWaitLite]
   *   wait until 'score' is greater than 10   wait for a condition [ImprovedWaitLite]
   *   wait at most 5 seconds until 'ready' is true                    [ImprovedWaitLite]
   *   wait for the actor 'hero' to finish     wait for an actor    [ImprovedWait]
   *   wait at most 5 seconds for the actor 'hero' to finish           [ImprovedWait]
   *   wait for a key press                    keyboard             [Keyboard]
   */
  Parser.prototype.parseWait = function () {
    var kw = this.advance(); // wait

    // wait for a key press  [Keyboard]
    if (this.isWord('for') && this.isWord('a', this.peek(1)) && this.isWord('key', this.peek(2))) {
      this.requireLibrary('wait for a key press', kw);
      this.advance(); // for
      this.advance(); // a
      this.advance(); // key
      this.expectWord('press', 'in "wait for a key press".');
      return EPP.AST.WaitForKey(kw);
    }

    // wait for the actor 'hero' to finish  [ImprovedWait]
    if (this.isWord('for') && this.isWord('the', this.peek(1)) && this.isWord('actor', this.peek(2))) {
      this.requireLibrary('wait for the actor', kw);
      this.advance(); // for
      this.advance(); // the
      this.advance(); // actor
      var actorToken = this.current();
      if (actorToken.type !== 'VARIABLE') {
        throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(actorToken) + '.',
          actorToken.line, actorToken.column,
          'Write it like this: wait for the actor \'hero\' to finish', 'E030');
      }
      this.advance();
      this.expectWord('to', 'in "wait for the actor \'hero\' to finish".');
      this.expectWord('finish', 'in "wait for the actor \'hero\' to finish".');
      var limitForActor = null;
      if (this.matchWord('in') || this.matchWord('within')) {
        limitForActor = this.parseExpression();
        this.matchWord('seconds'); this.matchWord('second');
      }
      return EPP.AST.WaitForActor(actorToken.value, limitForActor, kw);
    }

    // wait until <condition>  /  wait at most N seconds until <condition>
    // Release 1.5a1: waiting for a condition is core E++, so no library is
    // needed. The ImprovedWait libraries still bring actor waits, pause,
    // resume and stop.
    if (this.isWord('until')) {
      this.advance(); // until
      return EPP.AST.WaitUntil(this.parseCondition(), null, false, kw);
    }
    if (this.isWord('at') && this.isWord('most', this.peek(1))) {
      this.advance(); // at
      this.advance(); // most
      var limit = this.parseExpression();
      this.matchWord('seconds'); this.matchWord('second');
      if (this.matchWord('until')) {
        return EPP.AST.WaitUntil(this.parseCondition(), limit, true, kw);
      }
      if (this.isWord('for') && this.isWord('the', this.peek(1)) && this.isWord('actor', this.peek(2))) {
        this.requireLibrary('wait for the actor', kw);
        this.advance(); this.advance(); this.advance(); // for the actor
        var atMostActor = this.current();
        if (atMostActor.type !== 'VARIABLE') {
          throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(atMostActor) + '.',
            atMostActor.line, atMostActor.column,
            'Write it like this: wait at most 5 seconds for the actor \'hero\' to finish', 'E030');
        }
        this.advance();
        this.expectWord('to', 'in "wait at most 5 seconds for the actor \'hero\' to finish".');
        this.expectWord('finish', 'in "wait at most 5 seconds for the actor \'hero\' to finish".');
        return EPP.AST.WaitForActor(atMostActor.value, limit, kw);
      }
      // wait at most N seconds — a plain wait with a ceiling is just a wait.
      return EPP.AST.Wait(limit, kw);
    }

    var duration = this.parseExpression();
    // Release 1.5a1 (matching the other engines): milliseconds are a real
    // unit, so `wait 250 milliseconds` pauses for a quarter of a second.
    var durationMs = this.matchWord('milliseconds') || this.matchWord('millisecond');
    if (!durationMs) { this.matchWord('seconds'); this.matchWord('second'); }
    if (durationMs) duration = EPP.AST.Milliseconds(duration, kw);

    // wait 2 seconds as 'intro'  [ImprovedWaitLite]
    if (this.isWord('as') && this.peek(1) && this.peek(1).type === 'VARIABLE') {
      this.requireLibrary('named wait', kw);
      this.advance(); // as
      var timerName = this.advance().value;
      return EPP.AST.WaitNamed(duration, timerName, kw);
    }

    // wait 2 seconds and then say "Done!"  [ImprovedWaitLite]
    if (this.isWord('and') && this.isWord('then', this.peek(1))) {
      this.requireLibrary('wait and then', kw);
      this.advance(); // and
      this.advance(); // then
      if (this.isSeparator(this.current()) || this.atEnd()) {
        var badThen = this.current();
        throw new ParseError('"and then" needs an action after it, but the line ended.',
          badThen.line, badThen.column,
          'Write it like this: wait 2 seconds and then say "Done!"', 'E003');
      }
      return EPP.AST.WaitThen(duration, this.parseStatement(), null, kw);
    }

    return EPP.AST.Wait(duration, kw);
  };

  // Increase <variable> by <amount>  /  Decrease <variable> by <amount>
  // The variable may be written as a plain name (Increase score by 1) or
  // as a quoted reference (Increase 'score' by 1).
  Parser.prototype.parseIncreaseDecrease = function (isIncrease) {
    var kw = this.advance(); // Increase / Decrease
    var word = isIncrease ? 'Increase' : 'Decrease';
    var name;
    if (this.current().type === 'VARIABLE') {
      name = this.advance().value;
    } else {
      name = this.parseName('after "' + word + '", for example: ' + word + ' score by 1.');
    }
    if (!this.matchWord('by')) {
      var t = this.current();
      throw new ParseError(word + ' needs the word "by" before the amount, but found ' + this.describe(t) + '.',
        t.line, t.column, 'Write it like this: ' + word + ' ' + name + ' by 1.', 'E062');
    }
    if (this.isSeparator(this.current()) || this.atEnd()) {
      var t2 = this.current();
      throw new ParseError(word + ' ' + name + ' by needs an amount after "by".',
        t2.line, t2.column, 'For example: ' + word + ' ' + name + ' by 1.', 'E038');
    }
    var amount = this.parseExpression();
    return isIncrease ? EPP.AST.Increase(name, amount, kw) : EPP.AST.Decrease(name, amount, kw);
  }

  // python code "<python>"  /  python code ",<raw python block>,"  [Python]
  Parser.prototype.parsePython = function () {
    var kw = this.advance(); // python
    // Python code may only run when the Python library has been added.
    if (!this.loadedLibraries.Python) {
      throw new LibraryError(
        'You cannot run Python code yet, because the Python library has not been added.',
        kw.line, kw.column,
        'Add this line above your Python code: add library "Python" — then python code "..." will work.', 'E047');
    }
    if (!this.matchWord('code')) {
      var t0 = this.current();
      throw new ParseError('Python statements start with the words "python code", but found ' + this.describe(t0) + ' after "python".',
        t0.line, t0.column, 'Write it like this: python code "print(\'Hello\')"', 'E048');
    }
    var token = this.current();
    if (token.type !== 'STRING') {
      throw new ParseError('The Python code must be written inside double quotes, but found ' + this.describe(token) + '.',
        token.line, token.column,
        'For one line: python code "print(1 plus 2)" — for several lines, use commas: python code ",print(1)," and close the quote at the end.', 'E048');
    }
    this.advance();
    var code = token.value;
    var block = false;
    // Comma-mode / Dash-mode blocks were extracted before lexing and arrive as a
    // placeholder string holding the block's index.
    var placeholder = /^\u0001(\d+)\u0001$/.exec(code);
    if (placeholder) {
      var stored = this.pythonBlocks[Number(placeholder[1])];
      code = stored ? stored.code : '';
      block = true;
    } else if (code.charAt(0) === ',' || code.charAt(0) === '-') {
      block = true;
      code = code.slice(1);
    }
    if (!code.trim()) {
      throw new ParseError(block
        ? 'This Python code block is empty — there is no Python code after the opening comma.'
        : 'The Python code is empty — there is nothing between the quotes.',
        token.line, token.column,
        'Write some Python between the quotes, for example: python code "print(\'Hello\')"', 'E050');
    }
    return EPP.AST.PythonCode(code, kw, block);
  };


  // ------------------------------------------------------------------
  // Release 1.2 — Game library statements
  // ------------------------------------------------------------------

  /** create the actor 'hero' with the image "<source>" */
  Parser.prototype.parseCreateActor = function () {
    var kw = this.advance(); // create
    this.requireLibrary('create the actor', kw);
    this.matchWord('the');
    if (!this.matchWord('actor')) {
      var bad = this.current();
      throw new ParseError('Expected the word "actor" after "create" but found ' + this.describe(bad) + '.',
        bad.line, bad.column,
        'Write it like this: create the actor \'hero\' with the image "hero.png" — the Image button in the toolbar writes this line for you.', 'E062');
    }
    var nameToken = this.current();
    if (nameToken.type !== 'VARIABLE') {
      throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(nameToken) + '.',
        nameToken.line, nameToken.column,
        'Write it like this: create the actor \'hero\' with the image "hero.png"', 'E030');
    }
    this.advance();
    // The picture can come from the project's picture book instead:
    //   link the image "hero.png" to the actor 'hero'
    //   create the actor 'hero'
    // so `create` on its own means "use the picture this name is linked to".
    if (!this.isWord('with')) {
      return EPP.AST.DefineActor(nameToken.value, null, kw);
    }
    this.advance(); // with
    this.matchWord('the');
    if (!this.matchWord('image')) {
      var badImage = this.current();
      throw new ParseError('Expected the word "image" after "with" but found ' + this.describe(badImage) + '.',
        badImage.line, badImage.column,
        'Write it like this: create the actor \'hero\' with the image "hero.png"', 'E062');
    }
    var source = this.parseExpression();
    return EPP.AST.DefineActor(nameToken.value, source, kw);
  };

  /**
   * set the image of the actor 'hero' to "<source>"
   * link the image "<source>" to the actor 'hero'   (or: to the name 'hero')
   *
   * Both bind a picture to a name. `link` is the one to reach for: it makes
   * the name mean that picture from then on, so `create the actor 'hero'`
   * never needs to repeat the image.
   */
  Parser.prototype.parseActorImage = function (alreadyRead) {
    var kw = alreadyRead || this.advance(); // set / link

    if (kw.value.toLowerCase() === 'link') {
      this.requireLibrary('link the image', kw);
      this.matchWord('the');
      if (!this.matchWord('image')) {
        var badImage = this.current();
        throw new ParseError('Expected the word "image" after "link" but found ' + this.describe(badImage) + '.',
          badImage.line, badImage.column,
          'Write it like this: link the image "hero.png" to the actor \'hero\'', 'E062');
      }
      var linkSource = this.parseExpression();
      this.expectWord('to', 'in "link the image \"hero.png\" to the actor \'hero\'".');
      this.matchWord('the');
      if (!this.matchWord('actor') && !this.matchWord('name')) {
        var badTarget = this.current();
        throw new ParseError('Expected "actor" or "name" after "to" but found ' + this.describe(badTarget) + '.',
          badTarget.line, badTarget.column,
          'Write it like this: link the image "hero.png" to the actor \'hero\'', 'E062');
      }
      var linkName = this.current();
      if (linkName.type !== 'VARIABLE') {
        throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(linkName) + '.',
          linkName.line, linkName.column,
          'Write it like this: link the image "hero.png" to the actor \'hero\'', 'E030');
      }
      this.advance();
      return EPP.AST.LinkImage(linkName.value, linkSource, kw);
    }

    // set the image of the actor 'hero' to "<source>"
    if (!this.matchWord('the')) {
      var badThe = this.current();
      throw new ParseError('Expected "the" after "set" but found ' + this.describe(badThe) + '.',
        badThe.line, badThe.column,
        'Write it like this: set the image of the actor \'hero\' to "hero.png"', 'E062');
    }
    if (!this.matchWord('image')) {
      var badSetImage = this.current();
      throw new ParseError('Expected "image" after "set the" but found ' + this.describe(badSetImage) + '.',
        badSetImage.line, badSetImage.column,
        'Write it like this: set the image of the actor \'hero\' to "hero.png"', 'E062');
    }
    this.expectWord('of', 'in "set the image of the actor \'hero\' to ...".');
    this.matchWord('the');
    if (!this.matchWord('actor') && !this.matchWord('name')) {
      var badActor = this.current();
      throw new ParseError('Expected "actor" after "the image of" but found ' + this.describe(badActor) + '.',
        badActor.line, badActor.column,
        'Write it like this: set the image of the actor \'hero\' to "hero.png"', 'E062');
    }
    var actorToken = this.current();
    if (actorToken.type !== 'VARIABLE') {
      throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(actorToken) + '.',
        actorToken.line, actorToken.column,
        'Write it like this: set the image of the actor \'hero\' to "hero.png"', 'E030');
    }
    this.advance();
    this.expectWord('to', 'before the picture, for example: set the image of the actor \'hero\' to "hero.png".');
    this.requireLibrary('set the image of the actor', kw);
    var newSource = this.parseExpression();
    return EPP.AST.SetActorImage(actorToken.value, newSource, kw);
  };

  /** put the actor 'hero' at 100 and 200 */
  Parser.prototype.parsePlaceActor = function () {
    var kw = this.advance(); // put
    this.requireLibrary('put the actor', kw);
    this.matchWord('the');
    if (!this.matchWord('actor')) {
      var bad = this.current();
      throw new ParseError('Expected the word "actor" after "put" but found ' + this.describe(bad) + '.',
        bad.line, bad.column,
        'Write it like this: put the actor \'hero\' at 100 and 200', 'E062');
    }
    var nameToken = this.current();
    if (nameToken.type !== 'VARIABLE') {
      throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(nameToken) + '.',
        nameToken.line, nameToken.column, 'Write it like this: put the actor \'hero\' at 100 and 200', 'E030');
    }
    this.advance();
    this.expectWord('at', 'after the actor name, for example: put the actor \'hero\' at 100 and 200.');
    var x = this.parseExpression();
    this.expectWord('and', 'between the two numbers of the position.');
    var y = this.parseExpression();
    return EPP.AST.PlaceActor(nameToken.value, x, y, kw);
  };

  /** play the game ... end the game */
  Parser.prototype.parsePlayGame = function () {
    var kw = this.advance(); // play
    this.requireLibrary('play the game', kw);
    this.matchWord('the');
    if (!this.matchWord('game')) {
      var bad = this.current();
      throw new ParseError('Expected the word "game" after "play" but found ' + this.describe(bad) + '.',
        bad.line, bad.column, 'Write it like this: play the game ... end the game', 'E062');
    }
    var part = this.parseBranch(kw);
    if (part.block) {
      this.skipSeparators();
      if (!this.isWord('end')) {
        var t = this.current();
        throw new ParseError('This "play the game" block never ends.', t.line, t.column,
          'Close it with: end the game', 'E018');
      }
      this.advance(); // end
      this.matchWord('the');
      this.matchWord('game');
    }
    return EPP.AST.GameLoop(part.body, kw);
  };

  /** stop  /  stop the game  /  stop the actor 'hero'  /  stop every actor */
  Parser.prototype.parseStop = function (t) {
    this.advance(); // stop
    if (this.isSeparator(this.current()) || this.atEnd()) return EPP.AST.Stop(t);

    if (this.isWord('the') && this.isWord('game', this.peek(1))) {
      this.requireLibrary('stop the game', t);
      this.advance(); this.advance();
      return EPP.AST.StopGame(t);
    }

    if (this.isWord('every') && this.isWord('actor', this.peek(1))) {
      this.requireLibrary('stop every actor', t);
      this.advance(); this.advance();
      return EPP.AST.ActorAction('*', 'stop', t);
    }

    if (this.isWord('actor') || this.isWord('the')) {
      this.requireLibrary('stop the actor', t);
      this.matchWord('the');
      if (!this.matchWord('actor')) {
        var badA = this.current();
        throw new ParseError('Expected the word "actor" after "stop the" but found ' + this.describe(badA) + '.',
          badA.line, badA.column,
          'Write it like this: stop the actor \'enemy\' — or just "stop" on its own to end a loop.', 'E062');
      }
      var nameToken = this.current();
      if (nameToken.type !== 'VARIABLE') {
        throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(nameToken) + '.',
          nameToken.line, nameToken.column, 'Write it like this: stop the actor \'enemy\'', 'E030');
      }
      this.advance();
      return EPP.AST.ActorAction(nameToken.value, 'stop', t);
    }

    // A plain "stop" followed by an unrelated word is still a loop break.
    return EPP.AST.Stop(t);
  };

  /** pause the actor 'hero'  /  resume the actor 'hero' */
  Parser.prototype.parseActorControl = function (action) {
    var kw = this.advance(); // pause / resume
    this.requireLibrary(action + ' the actor', kw);
    this.matchWord('the');
    this.matchWord('actor');
    var nameToken = this.current();
    if (nameToken.type !== 'VARIABLE') {
      throw new ParseError('An actor needs a name in single quotes, but found ' + this.describe(nameToken) + '.',
        nameToken.line, nameToken.column,
        'Write it like this: ' + action + ' the actor \'hero\'', 'E030');
    }
    this.advance();
    return EPP.AST.ActorAction(nameToken.value, action, kw);
  };

  /** cancel the wait 'intro' */
  Parser.prototype.parseCancelWait = function () {
    var kw = this.advance(); // cancel
    this.requireLibrary('cancel the wait', kw);
    this.matchWord('the');
    if (!this.matchWord('wait')) {
      var bad = this.current();
      throw new ParseError('Expected the word "wait" after "cancel" but found ' + this.describe(bad) + '.',
        bad.line, bad.column, 'Write it like this: cancel the wait \'intro\'', 'E062');
    }
    var nameToken = this.current();
    if (nameToken.type !== 'VARIABLE') {
      throw new ParseError('A named wait needs a name in single quotes, but found ' + this.describe(nameToken) + '.',
        nameToken.line, nameToken.column, 'Write it like this: cancel the wait \'intro\'', 'E030');
    }
    this.advance();
    return EPP.AST.CancelWait(nameToken.value, kw);
  };

  Parser.prototype.parseLibrary = function () {
    var kw = this.advance(); // library
    var nameToken = this.current();
    if (nameToken.type !== 'STRING') {
      throw new ParseError('A library name must be written in double quotes, for example: add library "Math".',
        nameToken.line, nameToken.column, null, 'E044');
    }
    this.advance();
    if (this.options && this.options.fileName) {
      var fname = this.options.fileName;
      if (/\.eppl$/i.test(fname) && !/\.eppla$/i.test(fname)) {
        throw new LibraryError(
          'Files ending in .eppl cannot use libraries: a file that uses a library is an .eppla file.',
          nameToken.line, nameToken.column,
          'Rename this file to "' + fname.replace(/\.eppl$/i, '.eppla') + '" to use libraries.', 'E046');
      }
    }
    if (!(this.matchWord('add') || this.matchWord('load') || this.matchWord('import'))) {
      var t = this.current();
      throw new ParseError('Expected the word "add" after the library name, or use: add library "' + nameToken.value + '".',
        t.line, t.column, 'Write it like this: add library "' + nameToken.value + '".', 'E045');
    }
    if (!EPP.Libraries || !EPP.Libraries.isKnown(nameToken.value)) {
      var available = EPP.Libraries ? EPP.Libraries.names().join(', ') : 'Math';
      throw new LibraryError('There is no library called "' + nameToken.value + '".',
        nameToken.line, nameToken.column, 'Available libraries: ' + available + '.', 'E043');
    }
    var canonical = EPP.Libraries.canonical(nameToken.value);
    this.loadedLibraries[canonical] = true;
    return EPP.AST.Library(canonical, kw);
  };

  Parser.prototype.parseNote = function () {
    var kw = this.advance(); // note
    if (this.current().type === 'COLON') this.advance();
    // A note runs to the end of the statement; its words are ignored.
    while (!this.isSeparator(this.current()) && !this.atEnd()) this.advance();
    return EPP.AST.Note('', kw);
  };

  /**
   * Reads either an inline body (a single statement on the same line as
   * `markerToken`) or a block body (statements on following lines).
   * Returns { body: [...], block: boolean }.
   */
  Parser.prototype.parseBranch = function (markerToken) {
    var next = this.current();
    // A colon after the header (`repeat 3 times:` / `while ... do:` /
    // `if ... then:`) just opens the block; the block still ends with `end`.
    if (next && next.type === 'COLON') this.advance();
    next = this.current();
    var block = this.isSeparator(next) || next.type === 'EOF' || next.line !== markerToken.line;
    if (!block) {
      return { body: [this.parseStatement()], block: false };
    }
    this.skipSeparators();
    return { body: this.parseBlock(), block: true };
  };

  Parser.prototype.parseBlock = function () {
    var body = [];
    this.skipSeparators();
    while (!this.atEnd() && !this.isWord('end') && !this.isWord('otherwise') && !this.isChainConnectorAhead()) {
      body.push(this.parseStatement());
      this.skipSeparators();
    }
    return body;
  };

  /** True when the tokens ahead are an `and` chain connector: `and` then `otherwise`. */
  Parser.prototype.isChainConnectorAhead = function () {
    if (!this.isWord('and')) return false;
    var i = this.pos + 1;
    while (this.tokens[i] && this.isSeparator(this.tokens[i])) i += 1;
    return this.isWord('otherwise', this.tokens[i]);
  };

  /**
   * Consumes an `and` chain connector (`... <action> and` NEWLINE
   * `otherwise ...`), leaving the parser on the `otherwise`. Returns false
   * when there is no connector.
   */
  Parser.prototype.consumeChainConnector = function () {
    if (!this.isChainConnectorAhead()) return false;
    this.advance(); // and
    this.skipSeparators();
    return this.isWord('otherwise');
  };

  Parser.prototype.expectEnd = function (kind, openToken) {
    this.skipSeparators();
    var t = this.current();
    if (!this.isWord('end')) {
      throw new ParseError('This "' + kind + '" statement (started on line ' + openToken.line + ') never ends.',
        t.line, t.column, 'Close it with: end ' + kind, 'E018');
    }
    this.advance(); // end
    this.matchWord(kind);
    if (kind === 'if') this.matchWord('statement');
  };

  /**
   * Parses a condition for one branch of an if-chain. Inside a chain,
   * `not a number` with nothing in front of it tests the same value the
   * first condition in the chain tested (the natural way to check a typed
   * answer), e.g.:
   *   if 'age' is greater than 10 then ... otherwise if not a number then ...
   */
  Parser.prototype.parseBranchCondition = function (firstCondition) {
    var t = this.current();
    if (this.isWord('not') &&
        this.isWord('a', this.peek(1)) &&
        this.isWord('number', this.peek(2))) {
      this.advance(); this.advance(); this.advance();
      return EPP.AST.Condition('notNumber', firstCondition.left, null, t);
    }
    return this.parseCondition();
  };

  Parser.prototype.parseIf = function () {
    var kw = this.advance(); // if
    var firstCondition = this.parseCondition();
    var condition = firstCondition;
    // 1.4: a missing 'then' is E020, not the generic "expected the word"
    // of E062 - it is the one word an if cannot do without.
    if (!this.isWord('then')) {
      var missingThen = this.current();
      throw new ParseError('This if needs the word "then" after its condition, but found ' +
        this.describe(missingThen) + '.', missingThen.line, missingThen.column,
        'Write the decision like this: if 1 is 1 then say "Yes"', 'E020');
    }
    var thenToken = this.advance(); // then
    // `if ... then:` is the block form people write in the Studio; the colon
    // is decorative and the block is still closed by `end if`.
    if (this.current() && this.current().type === 'COLON') this.advance();

    // Parse the whole chain: if / (otherwise if)* / (otherwise)? — the
    // branches may be mixed inline and block forms, in any number.
    var branches = [];
    var firstPart = this.parseBranch(thenToken);
    var outerBlock = firstPart.block;
    // The chain itself starts on the `if` line; an `otherwise` that appears
    // on that same line is only legal in the inline form.

    branches.push({ condition: condition, body: firstPart.body });

    for (;;) {
      // A branch action may end with `and` to continue the chain below.
      var chained = this.consumeChainConnector();
      if (!chained) {
        var savedPos = this.pos;
        this.skipSeparators();
        if (!this.isWord('otherwise')) { this.pos = savedPos; break; }
      }
      var otherwiseToken = this.advance(); // otherwise

      if (this.isWord('if')) {
        this.advance(); // if
        condition = this.parseBranchCondition(firstCondition);
        thenToken = this.expectWord('then', 'after the otherwise-if condition.');
        if (this.current() && this.current().type === 'COLON') this.advance();
        var nextPart = this.parseBranch(thenToken);
        branches.push({ condition: condition, body: nextPart.body });
        continue;
      }

      // Final `otherwise` branch (no condition).
      var elsePart = this.parseBranch(otherwiseToken);
      branches.push({ condition: null, body: elsePart.body });
      break;
    }

    var thenBranch = branches[0].body;
    var last = branches[branches.length - 1];
    var elseBranch = last.condition === null && branches.length > 1 ? last.body : [];

    if (outerBlock) {
      // A block if must be closed with `end if` (also when one of its
      // branches was written inline, e.g. `otherwise say "x"`).
      this.expectEnd('if', kw);
    } else {
      this.consumeOptionalEndIf();
    }
    return EPP.AST.If(firstCondition, thenBranch, elseBranch, kw, branches);
  };

  /** Consumes a trailing `end if` when one is present; otherwise restores position. */
  Parser.prototype.consumeOptionalEndIf = function () {
    var savedPos = this.pos;
    this.skipSeparators();
    if (this.isWord('end')) {
      var after = this.peek(1);
      // `end` followed by another block word (repeat, while, game, ...)
      // belongs to an enclosing block — never swallow it as `end if`.
      if (after && after.type === 'WORD' && after.value.toLowerCase() !== 'if') {
        this.pos = savedPos;
        return;
      }
      this.advance(); // end
      this.matchWord('if');
      return;
    }
    this.pos = savedPos;
  };

  Parser.prototype.parseRepeat = function () {
    var kw = this.advance(); // repeat

    // Release 1.5a1 — repeat until <condition>. The loop keeps going while the
    // condition is false, which is how people already describe it out loud.
    if (this.isWord('until')) {
      this.advance(); // until
      var untilStart = this.current();
      if (!untilStart || untilStart.type === 'NEWLINE' || untilStart.type === 'EOF') {
        throw new ParseError('"repeat until" needs a condition to wait for.',
          untilStart ? untilStart.line : kw.line, untilStart ? untilStart.column : kw.column,
          "Write it like this: repeat until 'count' is 10", 'E027');
      }
      var untilCondition = this.parseCondition();
      var untilPart = this.parseBranch(kw);
      if (untilPart.block) this.expectEnd('repeat', kw);
      return EPP.AST.RepeatUntil(untilCondition, untilPart.body, kw);
    }

    // In "repeat 3 times", the word "times" ends the count — it is not the
    // multiplication operator. Suppress `times` as an operator while the
    // count is being read (use parentheses for a count containing `times`).
    this.timesSuppressed = (this.timesSuppressed || 0) + 1;
    var count;
    try { count = this.parseExpression(); }
    finally { this.timesSuppressed -= 1; }
    var marker = this.expectWord('times', 'in a repeat statement, for example: repeat 3 times, or repeat until a condition is true.');
    var part = this.parseBranch(marker);
    if (part.block) this.expectEnd('repeat', kw);
    return EPP.AST.Repeat(count, part.body, kw);
  };

  /**
   * Release 1.5a1 — delete the file "notes.txt" / remove the file "notes.txt"
   * The name may be text in double quotes or a single-quoted variable.
   */
  Parser.prototype.parseDeleteFile = function () {
    var kw = this.advance(); // delete / remove
    this.matchWord('the');
    if (!this.matchWord('file')) {
      var t = this.current();
      throw new ParseError('"' + kw.value + '" needs the word "file" after it, but found ' + this.describe(t) + '.',
        kw.line, kw.column, 'Write it like this: delete the file "notes.txt"', 'E015');
    }
    var valueToken = this.current();
    if (valueToken.type !== 'STRING' && valueToken.type !== 'VARIABLE' && valueToken.type !== 'WORD') {
      throw new ParseError('A file to delete needs a name, but found ' + this.describe(valueToken) + '.',
        valueToken.line, valueToken.column,
        'Write it like this: delete the file "notes.txt"', 'E052');
    }
    this.advance();
    var path = valueToken.type === 'STRING' ? EPP.AST.Literal(valueToken.value, valueToken)
      : valueToken.type === 'VARIABLE' ? EPP.AST.Variable(valueToken.value, valueToken)
        : EPP.AST.Literal(valueToken.value, valueToken);
    return EPP.AST.DeleteFile(path, kw);
  };

  Parser.prototype.parseForever = function () {
    var kw = this.advance();
    var part = this.parseBranch(kw);
    if (part.block) this.expectEnd('forever', kw);
    return EPP.AST.Forever(part.body, kw);
  };

  Parser.prototype.parseWhile = function () {
    var kw = this.advance(); // while
    // 1.4: `while` with nothing to test is E025.
    var first = this.current();
    if (!first || first.type === 'NEWLINE' || first.type === 'EOF' || first.type === 'PERIOD') {
      throw new ParseError('This while loop has no condition to test.',
        kw.line, kw.column,
        "Write the loop like this: while 'count' is less than 4 do", 'E025');
    }
    var condition = this.parseCondition();
    var marker = this.current();
    if (this.matchWord('do')) marker = this.tokens[this.pos - 1];
    var part = this.parseBranch(marker.type ? marker : kw);
    if (part.block) this.expectEnd('while', kw);
    return EPP.AST.While(condition, part.body, kw);
  };

  // ---------- conditions ----------
  /**
   * Release 1.5a2 — an E++ condition can be a whole sentence:
   *
   *   if 'score' is at least 10 and 'lives' is greater than 0 then ...
   *   if 'day' is "Saturday" or 'day' is "Sunday" then ...
   *   if not 'ready' then ...
   *
   * `not` belongs to one condition, `and` binds tighter than `or`, and each
   * side is an ordinary condition, so every comparison and library condition
   * below keeps working unchanged. A connector with nothing after it is E078.
   */
  Parser.prototype.parseCondition = function () {
    return this.parseOrCondition();
  };

  Parser.prototype.parseOrCondition = function () {
    var node = this.parseAndCondition();
    for (;;) {
      if (!this.isWord('or')) break;
      var orToken = this.advance();
      this.requireConditionAfter(orToken, 'or');
      node = EPP.AST.Logic('or', node, this.parseAndCondition(), orToken);
    }
    return node;
  };

  Parser.prototype.parseAndCondition = function () {
    var node = this.parseSimpleCondition();
    for (;;) {
      if (!this.isWord('and')) break;
      var andToken = this.advance();
      this.requireConditionAfter(andToken, 'and');
      node = EPP.AST.Logic('and', node, this.parseSimpleCondition(), andToken);
    }
    return node;
  };

  /** True when one pair of brackets wraps a whole condition, not just maths. */
  Parser.prototype.groupedConditionAhead = function () {
    var here = this.current();
    if (!here || here.type !== 'LPAREN') return false;
    var depth = 0, sawCondition = false;
    for (var i = this.pos; i < this.tokens.length; i += 1) {
      var token = this.tokens[i];
      if (token.type === 'LPAREN') { depth += 1; continue; }
      if (token.type === 'RPAREN') { depth -= 1; if (depth <= 0) return sawCondition; continue; }
      if (token.type === 'NEWLINE' || token.type === 'EOF') return false;
      if (depth >= 1 && token.type === 'WORD' &&
          /^(?:is|equals|equal|greater|less|lesser|exactly|different|at|no|more|not|and|or|number|contains|touching|a)$/i.test(token.value)) {
        sawCondition = true;
      }
    }
    return false;
  };

  /** "and" or "or" must be followed by another condition, not `then` or a line end. */
  Parser.prototype.requireConditionAfter = function (token, word) {
    var next = this.current();
    var bad = !next || this.isSeparator(next) || next.type === 'EOF' || next.type === 'COLON' ||
      this.isWord('then') || this.isWord('do') || this.isWord('and') || this.isWord('or') ||
      this.isWord('times') || this.isWord('end');
    if (bad) {
      throw EPP.Errors.error('E078',
        'This condition ends with "' + word + '", but there is no condition after it.',
        token.line, token.column,
        'Write two complete conditions, for example: if \'score\' is at least 10 ' + word + ' \'lives\' is greater than 0 then');
    }
  };

  Parser.prototype.parseSimpleCondition = function () {
    var t0 = this.current();

    // Release 1.5a2 — "not" in front of a condition turns it around. The
    // standalone "not a number" keeps its own E027 explanation below: it only
    // makes sense after an if about the same value.
    if (this.isWord('not') &&
        !(this.isWord('a', this.peek(1)) && this.isWord('number', this.peek(2)))) {
      var notToken = this.advance();
      this.requireConditionAfter(notToken, 'not');
      return EPP.AST.Logic('not', this.parseSimpleCondition(), null, notToken);
    }
    // Brackets around a whole condition let a reader choose the order of
    // and/or. A pair that only groups maths, such as "(1 plus 2) is 3", is
    // left to the expression parser.
    if (this.groupedConditionAhead()) {
      this.advance(); // (
      var grouped = this.parseCondition();
      this.expect('RPAREN', 'a closing ")" where the condition ends');
      return grouped;
    }

    // Release 1.2 — Keyboard: the "Up arrow" key is pressed  [Keyboard]
    // The name can be written with quotes (`the "Up arrow" key is pressed`)
    // or without them (`the Up arrow key is pressed`), because both read like
    // the sentence people actually say out loud.
    if (this.isWord('the') && this.peek(1) && this.peek(1).type === 'STRING' &&
        this.isWord('key', this.peek(2))) {
      this.requireLibrary('key is pressed', t0);
      this.advance(); // the
      var keyToken = this.advance(); // "Up arrow"
      this.expectWord('key', 'in "the \\"Up arrow\\" key is pressed".');
      this.expectWord('is', 'in "the \\"Up arrow\\" key is pressed".');
      var keyNegated = this.matchWord('not');
      this.expectWord('pressed', 'in "the \\"Up arrow\\" key is pressed".');
      return EPP.AST.KeyPressed(keyToken.value, keyNegated, t0);
    }
    if (this.isWord('the') && this.peek(1) && this.peek(1).type === 'WORD') {
      var keyWords = [];
      var scan = 1;
      while (this.peek(scan) && this.peek(scan).type === 'WORD' && !this.isWord('key', this.peek(scan))) {
        keyWords.push(this.peek(scan).value);
        scan += 1;
      }
      if (keyWords.length &&
          this.isWord('key', this.peek(scan)) &&
          this.isWord('is', this.peek(scan + 1))) {
        var looseNegated = this.isWord('not', this.peek(scan + 2));
        var pressedAt = scan + (looseNegated ? 3 : 2);
        if (this.isWord('pressed', this.peek(pressedAt))) {
          this.requireLibrary('key is pressed', t0);
          for (var keyStep = 0; keyStep < pressedAt; keyStep += 1) this.advance();
          this.advance(); // pressed
          return EPP.AST.KeyPressed(keyWords.join(' '), looseNegated, t0);
        }
      }
    }
    // `not a number` on its own has nothing to check here — it only makes
    // sense inside an otherwise-if chain (handled by parseBranchCondition)
    // or written in full as: if 'age' is not a number then ...
    if (this.isWord('not') &&
        this.isWord('a', this.peek(1)) &&
        this.isWord('number', this.peek(2))) {
      throw new ParseError('"not a number" needs a value to check, but nothing was written in front of it.',
        t0.line, t0.column,
        'Write it in full, for example: if \'age\' is not a number then say "Numbers only, please." — or use it in a chain after an if about the same value: otherwise if not a number then ...', 'E027');
    }
    var left = this.parseExpression();
    var t = this.current();

    // Dev Build 5: <value> contains <value> — core logic (no library needed)
    if (this.isWord('contains')) {
      this.advance(); // contains
      var contRight = this.parseExpression();
      return EPP.AST.Condition('contains', left, contRight, t);
    }

    if (this.isWord('equals')) {
      this.advance();
      var r1 = this.parseExpression();
      return EPP.AST.Condition('equal', left, r1, t);
    }
    if (!this.isWord('is')) {
      return EPP.AST.Condition('truthy', left, null, t);
    }
    this.advance(); // is
    var negated = this.matchWord('not');

    // Release 1.5a1: "is 1" and "is \"ready\"" mean "is equal to", exactly as
    // the C++ and Python engines already read them. Comparing with a plain
    // value used to be E026, which made wait until 'n' is 3 impossible to
    // write in the Studio.
    var afterIs = this.current();
    if (afterIs && (afterIs.type === 'NUMBER' || afterIs.type === 'STRING' ||
                    afterIs.type === 'VARIABLE' || afterIs.type === 'LPAREN')) {
      var plainRight = this.parseExpression();
      return EPP.AST.Condition(negated ? 'notEqual' : 'equal', left, plainRight, t);
    }

    // Release 1.2 — Game: if 'hero' is touching 'gem' then ...  [Game]
    if (this.isWord('touching') || this.isWord('touches')) {
      if (negated) {
        var badNeg = this.current();
        throw new ParseError('"is not touching" is written "is not touching" only in the other direction — E++ keeps it simple: use is touching and put the not in the branch.',
          badNeg.line, badNeg.column,
          'Write: if \'hero\' is touching \'gem\' then ... — and use otherwise for the other case.', 'E026');
      }
      this.requireLibrary('is touching', t);
      this.advance(); // touching
      var other = this.parseExpression();
      return EPP.AST.Condition('touching', left, other, t);
    }

    // Dev Build 5: is [not] a positive number / a negative number (Math library)
    if (this.isWord('a') && this.peek(1) && this.peek(1).type === 'WORD') {
      var nextWord = this.peek(1).value.toLowerCase();
      if (nextWord === 'positive') {
        this.advance(); // a
        this.advance(); // positive
        this.expectWord('number', 'in "is a positive number".');
        this.requireLibrary('is a positive number', t);
        return EPP.AST.Condition(negated ? 'notPositive' : 'positive', left, null, t);
      }
      if (nextWord === 'negative') {
        this.advance(); // a
        this.advance(); // negative
        this.expectWord('number', 'in "is a negative number".');
        this.requireLibrary('is a negative number', t);
        return EPP.AST.Condition(negated ? 'notNegative' : 'negative', left, null, t);
      }
    }

    // Dev Build 5: is [not] in the range of A to B (Math library)
    if (this.isWord('in') && this.peek(1) && this.peek(1).type === 'WORD' &&
        this.peek(1).value.toLowerCase() === 'the' &&
        this.peek(2) && this.peek(2).type === 'WORD' &&
        this.peek(2).value.toLowerCase() === 'range') {
      this.advance(); // in
      this.advance(); // the
      this.advance(); // range
      this.expectWord('of', 'in "is in the range of A to B".');
      this.requireLibrary('is in the range of', t);
      var low = this.parsePower();
      this.expectWord('to', 'in "is in the range of A to B" — write the upper bound after "to".');
      var high = this.parsePower();
      return EPP.AST.Condition(negated ? 'notInRange' : 'inRange', left, { low: low, high: high }, t);
    }

    // is a number / is not a number / is number / is not number
    if (this.isWord('a') || this.isWord('number')) {
      this.matchWord('a');
      if (!this.matchWord('number')) {
        var tnum = this.current();
        throw new ParseError('After "' + (negated ? 'is not a' : 'is a') + '" I expected the word "number", but found ' + this.describe(tnum) + '.',
          tnum.line, tnum.column, 'Write it like this: if \'age\' is not a number then say "Numbers only, please."', 'E026');
      }
      return EPP.AST.Condition(negated ? 'notNumber' : 'number', left, null, t);
    }

    if (this.matchWord('exactly')) {
      // Release 1.5a1 — "is exactly 5" reads the same as "is exactly equal to 5".
      if (this.matchWord('equal')) this.matchWord('to');
      var exreq = this.parseExpression();
      return EPP.AST.Condition(negated ? 'notExactEqual' : 'exactEqual', left, exreq, t);
    }
    // Release 1.5a1 — "is at least 5" / "is at most 5" (the plain-English pair).
    if (this.matchWord('at')) {
      var bound = this.current();
      var least = this.matchWord('least');
      if (!least && !this.matchWord('most')) {
        throw new ParseError('After "is at" I expected "least" or "most", but found ' + this.describe(bound) + '.',
          bound.line, bound.column, 'For example: if \'score\' is at least 10 then say "Passed".', 'E026');
      }
      var rb = this.parseExpression();
      return EPP.AST.Condition(least ? 'greaterOrEqual' : 'lessOrEqual', left, rb, t);
    }
    // Release 1.5a1 — "is no more than 5" / "is no less than 5".
    if (this.matchWord('no')) {
      var word = this.current();
      var more = this.matchWord('more');
      if (!more && !this.matchWord('less')) {
        throw new ParseError('After "is no" I expected "more than" or "less than", but found ' + this.describe(word) + '.',
          word.line, word.column, 'For example: if \'age\' is no more than 12 then say "Child ticket".', 'E026');
      }
      this.matchWord('than');
      var rn = this.parseExpression();
      return EPP.AST.Condition(more ? 'lessOrEqual' : 'greaterOrEqual', left, rn, t);
    }
    // Release 1.5a1 — "is more than 5" is the same as "is greater than 5".
    if (this.matchWord('more')) {
      this.matchWord('than');
      var rm = this.parseExpression();
      return EPP.AST.Condition('greater', left, rm, t);
    }
    // Release 1.5a1 — "is not 5" is the short form of "is not equal to 5", and
    // "is 5" is the short form of "is equal to 5". Both read as English.
    if (this.matchWord('equal')) {
      this.matchWord('to');
      var req = this.parseExpression();
      return EPP.AST.Condition(negated ? 'notEqual' : 'equal', left, req, t);
    }
    if (this.matchWord('different')) {
      this.expectWord('from', 'in "is different from".');
      var rd = this.parseExpression();
      return EPP.AST.Condition('notEqual', left, rd, t);
    }
    if (this.matchWord('greater')) {
      this.expectWord('than', 'in "is greater than".');
      if (this.matchWord('or')) {
        this.expectWord('equal', 'in "or equal to".');
        this.expectWord('to', 'in "or equal to".');
        var rge = this.parseExpression();
        return EPP.AST.Condition('greaterOrEqual', left, rge, t);
      }
      var rg = this.parseExpression();
      return EPP.AST.Condition('greater', left, rg, t);
    }
    if (this.matchWord('less') || this.matchWord('lesser')) {
      this.expectWord('than', 'in "is less than" (also written "is lesser than").');
      if (this.matchWord('or')) {
        this.expectWord('equal', 'in "or equal to".');
        this.expectWord('to', 'in "or equal to".');
        var rle = this.parseExpression();
        return EPP.AST.Condition('lessOrEqual', left, rle, t);
      }
      var rl = this.parseExpression();
      return EPP.AST.Condition('less', left, rl, t);
    }
    var bad = this.current();
    throw new ParseError('After "is" I expected a comparison such as "equal to", "greater than", "lesser than", "a positive number", "in the range of" or "not a number", but found ' +
      this.describe(bad) + '.', bad.line, bad.column,
      'For example: if \'score\' is equal to 10 then say "Perfect".', 'E026');
  };

  // ---------- expressions ----------
  Parser.prototype.parseExpression = function () {
    var expr = this.parseAdditive();
    // Postfix conversion applies to the whole expression:
    //   1 divided by 2 as fraction
    while (this.isWord('as')) {
      var asToken = this.current();
      var lookahead = this.peek(1);
      var kind = lookahead && lookahead.type === 'WORD' ? lookahead.value.toLowerCase() : '';
      if (kind !== 'fraction' && kind !== 'decimal') break;
      this.requireLibrary('as ' + kind, asToken);
      this.advance(); this.advance();
      expr = EPP.AST.Conversion(kind, expr, asToken);
    }
    return expr;
  };

  Parser.prototype.parseAdditive = function () {
    var left = this.parseMultiplicative();
    while (this.isWord('plus') || this.isWord('minus')) {
      var op = this.advance();
      var right = this.parseMultiplicative();
      left = EPP.AST.Binary(op.value.toLowerCase(), left, right, op);
    }
    return left;
  };

  Parser.prototype.parseMultiplicative = function () {
    var left = this.parsePower();
    for (;;) {
      if (this.isWord('times') && !this.timesSuppressed) {
        var t1 = this.advance();
        left = EPP.AST.Binary('times', left, this.parsePower(), t1);
      } else if (this.isWord('divided')) {
        var t2 = this.current();
        this.requireLibrary('divided by', t2);
        this.advance();
        this.expectWord('by', 'in "divided by".');
        left = EPP.AST.Binary('dividedBy', left, this.parsePower(), t2);
      } else if (this.isWord('percent')) {
        var t3 = this.current();
        this.requireLibrary('percent of', t3);
        this.advance();
        this.expectWord('of', 'in "percent of", for example: 50 percent of 200.');
        left = EPP.AST.PercentOf(left, this.parsePower(), t3);
      } else break;
    }
    return left;
  };

  Parser.prototype.parsePower = function () {
    var left = this.parseUnary();
    if (this.isWord('power')) {
      var t = this.current();
      this.requireLibrary('power of', t);
      this.advance();
      this.expectWord('of', 'in "power of", for example: 2 power of 3.');
      var right = this.parsePower(); // right-associative
      return EPP.AST.Binary('powerOf', left, right, t);
    }
    return left;
  };

  Parser.prototype.parseUnary = function () {
    var t = this.current();
    if (this.isWord('minus')) {
      this.advance();
      return EPP.AST.Unary('minus', this.parseUnary(), t);
    }
    // `the square root of 144` and `square root of 144` both read naturally.
    if (this.isWord('the') && this.isWord('square', this.peek(1)) && this.isWord('root', this.peek(2))) {
      this.advance();
      t = this.current();
    }
    if (this.isWord('square')) {
      this.requireLibrary('square root of', t);
      this.advance();
      this.expectWord('root', 'in "square root of".');
      this.expectWord('of', 'in "square root of".');
      return EPP.AST.SquareRoot(this.parseUnary(), t);
    }
    return this.parsePrimary();
  };

  Parser.prototype.parsePrimary = function () {
    var t = this.current();

    if (t.type === 'NUMBER') { this.advance(); return EPP.AST.Literal(parseFloat(t.value), t); }
    if (t.type === 'STRING') { this.advance(); return EPP.AST.Literal(t.value, t); }
    if (t.type === 'VARIABLE') { this.advance(); return EPP.AST.Variable(t.value, t); }

    if (t.type === 'LPAREN') {
      this.advance();
      var inner = this.parseExpression();
      this.expect('RPAREN', 'a closing ")"');
      return inner;
    }

    if (t.type === 'WORD') {
      var word = t.value.toLowerCase();

      // Built-in version value: `the version of E++` is available without a
      // library, so showcase programs can identify the runtime dynamically.
      if (word === 'the' && this.isWord('version', this.peek(1)) && this.isWord('of', this.peek(2))) {
        var versionName = this.peek(3);
        if (versionName && versionName.type === 'WORD' && versionName.value.toLowerCase() === 'e++') {
          this.advance(); this.advance(); this.advance(); this.advance();
          return EPP.AST.Literal(EPP.VERSION || '1.5a2', t);
        }
        // Accept token streams from the native lexer, which represents the
        // two plus signs as punctuation instead of one E++ word.
        if (versionName && versionName.type === 'WORD' && versionName.value.toLowerCase() === 'e' &&
            this.peek(4) && this.peek(4).value === '+' && this.peek(5) && this.peek(5).value === '+') {
          for (var vi = 0; vi < 6; vi += 1) this.advance();
          return EPP.AST.Literal(EPP.VERSION || '1.5a2', t);
        }
      }

      // Release 1.2 — Keyboard: the key pressed  [Keyboard]
      if (word === 'the' && this.isWord('key', this.peek(1)) && this.isWord('pressed', this.peek(2))) {
        this.requireLibrary('the key pressed', t);
        this.advance(); // the
        this.advance(); // key
        this.advance(); // pressed
        return EPP.AST.KeyPressed('*', false, t);
      }

      // `the length of "hello"` and `length of "hello"` are the same thing.
      if (word === 'the' && this.peek(1).type === 'WORD') {
        var articleWord = this.peek(1).value.toLowerCase();
        if (articleWord === 'uppercase' || articleWord === 'lowercase' || articleWord === 'length' ||
            articleWord === 'reverse' || articleWord === 'trim' || articleWord === 'trimmed' ||
            articleWord === 'first' || articleWord === 'last' ||
            articleWord === 'maximum' || articleWord === 'minimum' || articleWord === 'absolute' ||
            articleWord === 'value') {
          this.advance();
          t = this.current();
          word = t.value.toLowerCase();
        }
      }

      // `a random number between ...` reads as well as `random number between ...`.
      if ((word === 'a' || word === 'the') && this.isWord('random', this.peek(1))) {
        this.advance();
        t = this.current();
        word = t.value.toLowerCase();
      }

      if (word === 'true' || word === 'yes') { this.advance(); return EPP.AST.Literal(true, t); }
      if (word === 'false' || word === 'no') { this.advance(); return EPP.AST.Literal(false, t); }

      // Text library functions.
      if (word === 'uppercase' || word === 'lowercase' || word === 'length' ||
          word === 'reverse' || word === 'trim' || word === 'trimmed') {
        var textFunction = word === 'trimmed' ? 'trim' : word;
        this.requireLibrary(textFunction + ' of', t);
        this.advance();
        this.expectWord('of', 'in "' + word + ' of".');
        return EPP.AST.TextFunction(textFunction, this.parseUnary(), t);
      }

      // `first letter of` and `last letter of`.
      if (word === 'first' || word === 'last') {
        this.requireLibrary(word + ' letter of', t);
        this.advance();
        this.expectWord('letter', 'in "' + word + ' letter of".');
        this.expectWord('of', 'in "' + word + ' letter of".');
        return EPP.AST.TextFunction(word + ' letter', this.parseUnary(), t);
      }

      // Math library words: the maximum/minimum/absolute value of ...
      if (word === 'maximum' || word === 'minimum') {
        this.requireLibrary(word + ' of', t);
        this.advance();
        this.expectWord('of', 'in "the ' + word + ' of A and B".');
        var firstArg = this.parseAdditive();
        this.expectWord('and', 'between the two values, for example: the ' + word + ' of 3 and 9.');
        var secondArg = this.parseAdditive();
        return EPP.AST.MathFunction(word, [firstArg, secondArg], t);
      }

      if (word === 'absolute') {
        this.requireLibrary('absolute value of', t);
        this.advance();
        this.expectWord('value', 'in "the absolute value of a number".');
        this.expectWord('of', 'in "the absolute value of a number".');
        return EPP.AST.MathFunction('absolute value', [this.parseAdditive()], t);
      }

      // `the value of pi` and a bare `pi`.
      if (word === 'value') {
        this.requireLibrary('value of pi', t);
        this.advance();
        this.expectWord('of', 'in "the value of pi".');
        var constant = this.current();
        var constantName = constant && constant.type === 'WORD' ? constant.value.toLowerCase() : '';
        if (constantName !== 'pi' && constantName !== 'e') {
          throw new ParseError('Only pi and e have a fixed value here.', constant.line, constant.column,
            'Write: the value of pi', 'E027');
        }
        this.advance();
        return EPP.AST.MathConstant(constantName, t);
      }

      if (word === 'pi') {
        this.requireLibrary('value of pi', t);
        this.advance();
        return EPP.AST.MathConstant('pi', t);
      }

      // Random library function.
      if (word === 'random') {
        this.requireLibrary('random number between ... and ...', t);
        this.advance();
        this.expectWord('number', 'in "random number between ... and ...".');
        this.expectWord('between', 'in "random number between ... and ...".');
        var low = this.parsePower();
        this.expectWord('and', 'between the two numbers.');
        var high = this.parsePower();
        return EPP.AST.RandomNumber(low, high, t);
      }

      if (RESERVED[word]) {
        throw new ParseError('Expected a value but found the word "' + t.value + '".',
          t.line, t.column,
          'Values can be "text in quotes", \'a variable\', a number, or maths such as 1 plus 1.', 'E003');
      }

      // Reject unquoted values during parsing, including in inactive branches.
      var words = [];
      var first = t;
      while (this.current().type === 'WORD' && !RESERVED[this.current().value.toLowerCase()]) {
        words.push(this.advance().value);
      }
      var text = words.join(' '), plural = words.length > 1;
      throw new ParseError((plural ? 'The words "' + text + '" do' : 'The word "' + text + '" does') +
        ' not mean anything in E++ yet — text requires double quotes and variables must be written inside single quotes.',
        first.line, first.column,
        'Write "' + text + '" for text or use single quotes for a variable.', 'E001');
    }

    throw new ParseError('Expected a value but found ' + this.describe(t) + '.',
      t.line, t.column,
      'Values can be "text in quotes", \'a variable\', a number, or maths such as 1 plus 1.', 'E003');
  };

  Parser.parse = function (source, options) { return new Parser(source, options).parse(); };
  /**
   * Release 1.4: the same parse, with the Parser left in the caller's hands
   * so it can read `usedFeatures` (every library feature the source mentions).
   */
  Parser.instance = function (source, options) { return new Parser(source, options); };

  EPP.Parser = Parser;
  EPP.extractPythonBlocks = extractPythonBlocks;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Parser: Parser };
  }
})(typeof window !== 'undefined' ? window : globalThis);
